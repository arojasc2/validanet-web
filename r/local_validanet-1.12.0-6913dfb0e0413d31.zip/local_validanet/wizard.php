<?php
require_once('../../config.php');
require_login();
require_capability('moodle/site:config', context_system::instance());

$PAGE->set_context(context_system::instance());
$PAGE->set_url(new moodle_url('/local/validanet/wizard.php'));
$PAGE->set_title('ValidaNet — Configuración');
$PAGE->set_heading('ValidaNet — Configuración inicial');

$base  = $CFG->wwwroot . '/local/validanet/wizard.php';
$ajax  = $CFG->wwwroot . '/local/validanet/ajax.php';
$sk    = sesskey();

// ── ACCIÓN: Finalizar (ping exitoso desde JS) ─────────────
if (optional_param('wstep','',PARAM_ALPHANUMEXT) === 'finish'
    && confirm_sesskey(optional_param('sesskey','',PARAM_RAW))) {
    set_config('wizard_done', 1, 'local_validanet');
    redirect(new moodle_url('/admin/index.php'),
             '✅ ValidaNet configurado correctamente', 3);
}

echo $OUTPUT->header();
?>
<style>
.vn-wrap{max-width:680px;margin:30px auto;font-family:system-ui,sans-serif;}
.vn-step{background:#fff;border:1px solid #e2e8f0;border-radius:12px;padding:24px;margin-bottom:16px;}
.vn-step h3{margin:0 0 8px;font-size:17px;display:flex;align-items:center;gap:8px;}
.vn-step p{margin:6px 0;color:#475569;font-size:14px;}
.vn-btn{background:#16a34a;color:#fff;border:none;border-radius:8px;padding:11px 24px;
        font-size:14px;font-weight:600;cursor:pointer;transition:opacity .2s;}
.vn-btn:hover{opacity:.88;}
.vn-btn:disabled{opacity:.5;cursor:not-allowed;}
.vn-btn-blue{background:#1e40af;}
.vn-status{margin-top:10px;padding:10px 14px;border-radius:8px;font-size:13px;display:none;}
.vn-ok{background:#f0fdf4;border:1px solid #86efac;color:#15803d;}
.vn-err{background:#fef2f2;border:1px solid #fca5a5;color:#991b1b;}
.vn-inp{width:100%;padding:10px 12px;border:1.5px solid #e2e8f0;border-radius:8px;
        font-size:14px;margin-top:8px;box-sizing:border-box;}
.vn-inp:focus{outline:none;border-color:#3b82f6;}
.vn-progress{display:flex;gap:8px;margin-bottom:24px;}
.vn-dot{flex:1;height:6px;border-radius:99px;background:#e2e8f0;}
.vn-dot.done{background:#16a34a;}
.vn-dot.active{background:#3b82f6;}
</style>

<div class="vn-wrap">
  <img src="https://app.validanet.cl/static/logo_validanet.png"
       style="height:36px;margin-bottom:20px;" alt="ValidaNet">
  <h2 style="margin:0 0 6px;font-size:22px;">Configuración inicial</h2>
  <p style="color:#64748b;margin:0 0 20px;">El asistente configura todo automáticamente en menos de 2 minutos.</p>

  <div class="vn-progress">
    <div class="vn-dot active" id="dot1"></div>
    <div class="vn-dot" id="dot2"></div>
    <div class="vn-dot" id="dot3"></div>
  </div>

  <!-- PASO 1 -->
  <div class="vn-step" id="step1">
    <h3>⚡ Paso 1 — Activar servicios web</h3>
    <p>Habilita la API REST de Moodle para que ValidaNet pueda comunicarse con tu plataforma.</p>
    <button class="vn-btn" id="btn1" onclick="doStep1()">Activar automáticamente →</button>
    <div class="vn-status" id="st1"></div>
  </div>

  <!-- PASO 2 -->
  <div class="vn-step" id="step2" style="opacity:.5;pointer-events:none;">
    <h3>🔧 Paso 2 — Crear servicio y token</h3>
    <p>Crea el servicio <strong>ValidaNet API</strong> con todas las funciones necesarias
       y genera el token de acceso automáticamente.</p>
    <button class="vn-btn vn-btn-blue" id="btn2" onclick="doStep2()">Crear servicio →</button>
    <div class="vn-status" id="st2"></div>
  </div>

  <!-- PASO 3 -->
  <div class="vn-step" id="step3" style="opacity:.5;pointer-events:none;">
    <h3>🔗 Paso 3 — Conectar con ValidaNet</h3>
    <p>Ingresa tu <strong>API Key</strong> de ValidaNet para vincular tu Moodle.</p>
    <p style="font-size:12px;color:#94a3b8;">
      Encuéntrala en <strong>app.validanet.cl → Configuración → Mi Cuenta</strong>
    </p>
    <input type="text" id="apikey_inp" class="vn-inp"
           placeholder="vn-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx">
    <button class="vn-btn" id="btn3" onclick="doStep3()" style="margin-top:10px;">
      Conectar →
    </button>
    <div class="vn-status" id="st3"></div>
  </div>
</div>

<script>
var AJAX = '<?php echo $ajax; ?>';
var SK   = '<?php echo $sk; ?>';
var BASE = '<?php echo $base; ?>';

function setStatus(id, ok, msg) {
    var el = document.getElementById('st'+id);
    el.className = 'vn-status ' + (ok ? 'vn-ok' : 'vn-err');
    el.textContent = msg;
    el.style.display = 'block';
}
function unlockStep(n) {
    var s = document.getElementById('step'+n);
    s.style.opacity = '1';
    s.style.pointerEvents = 'auto';
    var dots = ['dot1','dot2','dot3'];
    for (var i=0; i<dots.length; i++) {
        document.getElementById(dots[i]).className =
            'vn-dot' + (i < n-1 ? ' done' : (i === n-1 ? ' active' : ''));
    }
    s.scrollIntoView({behavior:'smooth', block:'center'});
}

async function doStep1() {
    var btn = document.getElementById('btn1');
    btn.disabled = true; btn.textContent = '⏳ Activando...';
    try {
        var r = await fetch(AJAX + '?action=enable_webservices&sesskey='+SK);
        var d = await r.json();
        if (d.ok) {
            setStatus(1, true, '✅ Servicios web activados correctamente');
            btn.textContent = '✅ Listo';
            unlockStep(2);
        } else {
            setStatus(1, false, '❌ Error: ' + (d.error||'desconocido'));
            btn.disabled = false; btn.textContent = 'Reintentar';
        }
    } catch(e) {
        setStatus(1, false, '❌ Error de conexión: ' + e);
        btn.disabled = false; btn.textContent = 'Reintentar';
    }
}

async function doStep2() {
    var btn = document.getElementById('btn2');
    btn.disabled = true; btn.textContent = '⏳ Creando servicio y token...';
    try {
        var r = await fetch(AJAX + '?action=create_service&sesskey='+SK);
        var d = await r.json();
        if (d.ok) {
            setStatus(2, true,
                '✅ Servicio creado con ' + d.functions + ' funciones. ' +
                'Token generado automáticamente.');
            btn.textContent = '✅ Listo';
            unlockStep(3);
        } else {
            setStatus(2, false, '❌ Error: ' + (d.error||'desconocido'));
            btn.disabled = false; btn.textContent = 'Reintentar';
        }
    } catch(e) {
        setStatus(2, false, '❌ Error de conexión: ' + e);
        btn.disabled = false; btn.textContent = 'Reintentar';
    }
}

async function doStep3() {
    var apikey = document.getElementById('apikey_inp').value.trim();
    if (!apikey) { alert('Ingresa tu API Key de ValidaNet'); return; }
    var btn = document.getElementById('btn3');
    btn.disabled = true; btn.textContent = '⏳ Conectando...';
    try {
        var r = await fetch(AJAX + '?action=test_connection&apikey='
                            + encodeURIComponent(apikey) + '&sesskey=' + SK);
        var d = await r.json();
        if (d.ok) {
            setStatus(3, true, '✅ Conexión exitosa. Redirigiendo...');
            btn.textContent = '✅ Conectado';
            setTimeout(function(){
                window.location = BASE + '?wstep=finish&sesskey=' + SK;
            }, 1500);
        } else {
            setStatus(3, false, '❌ ' + (d.error||'API Key inválida'));
            btn.disabled = false; btn.textContent = 'Reintentar';
        }
    } catch(e) {
        setStatus(3, false, '❌ Error de conexión: ' + e);
        btn.disabled = false; btn.textContent = 'Reintentar';
    }
}
</script>
<?php echo $OUTPUT->footer(); ?>
