<?php
/**
 * Install script de local_validanet.
 *
 * Habilita webservices + protocolo REST + carácter extendido en usernames
 * (necesario para usar el RUT chileno '12345678-k' como username). El
 * servicio externo 'validanet_api' se crea via db/services.php; el wizard
 * (settings.php) sigue siendo el lugar para emitir el token + sincronizarlo
 * con app.validanet.cl.
 */
function xmldb_local_validanet_install() {
    global $CFG;

    set_config('wizard_done', 0, 'local_validanet');
    set_config('local_validanet_setup_pending', 1);

    // Habilitar subsistema WS y protocolo REST automáticamente.
    set_config('enablewebservices', 1);
    $protocols = get_config(null, 'webserviceprotocols') ?: '';
    if (strpos((string) $protocols, 'rest') === false) {
        set_config(
            'webserviceprotocols',
            trim(($protocols ? $protocols . ',' : '') . 'rest', ',')
        );
    }
    set_config('extendedusernamechars', 1);

    return true;
}
