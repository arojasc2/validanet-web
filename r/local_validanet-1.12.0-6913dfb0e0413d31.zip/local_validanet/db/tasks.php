<?php
// Scheduled tasks de local_validanet. Moodle las descubre en cada upgrade
// del plugin y las planifica según el cron declarado aquí.
defined('MOODLE_INTERNAL') || die();

$tasks = [
    [
        'classname' => 'local_validanet\\task\\heartbeat_task',
        'blocking'  => 0,
        // Diaria a las 03:17 (offset random para no saturar backend si
        // muchos Moodles tienen el mismo cron).
        'minute'    => '17',
        'hour'      => '3',
        'day'       => '*',
        'month'     => '*',
        'dayofweek' => '*',
    ],
    [
        'classname' => 'local_validanet\\task\\sync_courses_task',
        'blocking'  => 0,
        // Diaria a las 04:23 (offset distinto del heartbeat para no
        // saturar la API ValidaNet ni Moodle al mismo tiempo). La sync
        // descarga contenido por curso (puede demorar segundos).
        'minute'    => '23',
        'hour'      => '4',
        'day'       => '*',
        'month'     => '*',
        'dayofweek' => '*',
    ],
    [
        'classname' => 'local_validanet\\task\\auto_update_task',
        'blocking'  => 0,
        // Cada 6h (00:42, 06:42, 12:42, 18:42). Gateada por setting
        // auto_update_enabled — si está off, retorna sin trabajo. El
        // intervalo corto permite que un cliente reciba un hotfix dentro
        // de horas sin esperar al cron diario.
        'minute'    => '42',
        'hour'      => '*/6',
        'day'       => '*',
        'month'     => '*',
        'dayofweek' => '*',
    ],
];
