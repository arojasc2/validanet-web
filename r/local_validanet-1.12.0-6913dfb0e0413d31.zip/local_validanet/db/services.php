<?php
// Servicio declarativo "validanet_api". Moodle reconcilia este archivo en cada
// upgrade — toda función que llame el backend de ValidaNet debe aparecer aquí
// para que el upgrade no la borre silenciosamente.
//
// Si añades funciones, actualiza también la lista hardcoded del wizard
// (ajax.php → case 'create_service') para mantener compatibilidad con plugins
// ya instalados sin upgrade.
defined('MOODLE_INTERNAL') || die();

$functions = [];

$services = [
    'ValidaNet API' => [
        'functions' => [
            // — Site / identidad
            'core_webservice_get_site_info',

            // — Cursos
            'core_course_get_courses',
            'core_course_get_courses_by_field',
            'core_course_get_contents',
            'core_course_search_courses',
            'core_course_get_categories',

            // — Usuarios
            'core_user_get_users_by_field',
            'core_user_get_users',
            'core_user_create_users',
            'core_user_update_users',
            'core_user_delete_users',

            // — Matrículas
            'core_enrol_get_enrolled_users',
            'core_enrol_get_users_courses',
            'enrol_manual_enrol_users',
            'enrol_manual_unenrol_users',

            // — SSO autologin (alumno entra directo al curso desde CampusStore)
            'tool_mobile_get_autologin_key',
            'tool_mobile_get_public_config',
            'auth_email_get_signup_settings',

            // — Grupos (usadas por moodle_reports_client.py)
            'core_group_get_course_groups',
            'core_group_get_group_members',

            // — Completion
            'core_completion_get_course_completion_status',
            'core_completion_get_activities_completion_status',
            'core_completion_update_activity_completion_status_manually',

            // — Calificaciones
            'gradereport_user_get_grade_items',
            'gradereport_overview_get_course_grades',
            'core_grades_get_gradeitems',

            // — Actividades
            'mod_assign_get_assignments',
            'mod_assign_get_submission_status',
            'mod_assign_get_submissions',
            'mod_assign_save_grade',
            'mod_assign_save_grades',
            'mod_quiz_get_quizzes_by_courses',
            'mod_quiz_get_user_attempts',
            'mod_quiz_get_attempt_data',
            'mod_quiz_get_attempt_review',
            'mod_forum_get_forums_by_courses',
            'mod_forum_get_discussion_posts',
            'mod_resource_get_resources_by_courses',
            'mod_url_get_urls_by_courses',
            'mod_page_get_pages_by_courses',

            // — Mensajería
            'core_message_send_messages',
            'core_message_get_messages',

            // ────────────────────────────────────────────────────────────────
            // — Courses AI Builder (1.6.1+) — funciones de ESCRITURA/CREACIÓN
            //   requeridas por el orquestador que arma cursos completos en
            //   Moodle automáticamente desde un plan formativo (SENCE/OTEC).
            // ────────────────────────────────────────────────────────────────
            // Curso skeleton + categorías + secciones
            'core_course_create_courses',
            'core_course_update_courses',
            'core_course_delete_courses',
            'core_course_delete_modules',
            'core_course_edit_section',
            'core_course_create_categories',
            'core_course_get_course_module',

            // Archivos (SCORM, H5P, imágenes, documentos del curso)
            'core_files_upload',
            'core_files_get_files',

            // Asignación tutor académico + administrativo al curso
            'core_role_assign_roles',
            'core_role_unassign_roles',

            // Glosario por módulo (≥3 recursos por aprendizaje esperado)
            'mod_glossary_get_glossaries_by_courses',
            'mod_glossary_add_entry',

            // Cuestionarios (diagnóstica, parcial, final) — Builder genera
            // banco de preguntas y las cuelga al quiz
            'mod_quiz_save_questions',

            // Foros obligatorios por módulo
            'mod_forum_add_discussion',

            // Encuesta de satisfacción al final del curso
            'mod_feedback_get_feedback_access_information',
            'mod_feedback_get_feedbacks_by_courses',
            // F4 sync — agregados de respuestas para alimentar ERP
            'mod_feedback_get_analysis',
            'mod_feedback_get_responses_analysis',
            'mod_feedback_get_finished_responses',
            'mod_feedback_get_non_respondents',

            // H5P (Branching Scenario, Course Presentation, Interactive Video)
            // — Moodle 4.x core mod_h5pactivity, ≥3.9 supports
            'core_h5p_get_trusted_h5p_file',
            'mod_h5pactivity_get_h5pactivity_access_information',
            'mod_h5pactivity_get_h5pactivities_by_courses',
            'mod_h5pactivity_get_user_attempts',

            // ────────────────────────────────────────────────────────────────
            // — Custom WS del plugin (1.7.0+) — escritura granular que Moodle
            //   core NO expone (renombrar secciones con summary, crear mod_page).
            // ────────────────────────────────────────────────────────────────
            'local_validanet_update_section',
            'local_validanet_create_page',
            // — Batch v1.8.0 — Builder IA completo (glosario, quizzes, feedback)
            'local_validanet_create_module',
            'local_validanet_create_quiz',
            'local_validanet_add_quiz_questions_gift',
            'local_validanet_set_feedback_items',
            'local_validanet_update_page',
            'local_validanet_create_resource_with_file',
            'local_validanet_debug_read_quiz_questions',
            'local_validanet_debug_read_feedback_item',
            'local_validanet_add_quiz_questions_json',
            'local_validanet_delete_modules',
            'local_validanet_create_h5p_activity',
            'local_validanet_update_module_availability',
        ],
        'restrictedusers' => 0,
        'enabled'         => 1,
        'shortname'       => 'validanet_api',
        'downloadfiles'   => 1,
        'uploadfiles'     => 1,  // 1.6.1+ — necesario para SCORM/H5P upload
    ],
];

// Definición de las funciones custom del plugin (clases external/*).
$functions = [
    'local_validanet_update_section' => [
        'classname'    => 'local_validanet\\external\\update_section',
        'methodname'   => 'execute',
        'description'  => 'Renombra y/o setea summary/visible de una sección.',
        'type'         => 'write',
        'capabilities' => 'moodle/course:update',
        'services'     => ['validanet_api'],
    ],
    'local_validanet_create_page' => [
        'classname'    => 'local_validanet\\external\\create_page',
        'methodname'   => 'execute',
        'description'  => 'Crea una actividad mod_page en una sección del curso.',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities, mod/page:addinstance',
        'services'     => ['validanet_api'],
    ],
    'local_validanet_create_module' => [
        'classname'    => 'local_validanet\\external\\create_module',
        'methodname'   => 'execute',
        'description'  => 'Crea una actividad genérica (glossary, forum, url, label, etc).',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'services'     => ['validanet_api'],
    ],
    'local_validanet_create_quiz' => [
        'classname'    => 'local_validanet\\external\\create_quiz',
        'methodname'   => 'execute',
        'description'  => 'Crea un mod_quiz con preset SENCE (diagnostic/formative/partial/summative).',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities, mod/quiz:addinstance',
        'services'     => ['validanet_api'],
    ],
    'local_validanet_add_quiz_questions_gift' => [
        'classname'    => 'local_validanet\\external\\add_quiz_questions_gift',
        'methodname'   => 'execute',
        'description'  => 'Importa preguntas en formato GIFT al banco y las agrega al quiz.',
        'type'         => 'write',
        'capabilities' => 'mod/quiz:manage, moodle/question:add',
        'services'     => ['validanet_api'],
    ],
    'local_validanet_set_feedback_items' => [
        'classname'    => 'local_validanet\\external\\set_feedback_items',
        'methodname'   => 'execute',
        'description'  => 'Reemplaza/define los items (preguntas) de una mod_feedback.',
        'type'         => 'write',
        'capabilities' => 'mod/feedback:edititems',
        'services'     => ['validanet_api'],
    ],
    'local_validanet_update_page' => [
        'classname'    => 'local_validanet\\external\\update_page',
        'methodname'   => 'execute',
        'description'  => 'Actualiza nombre/contenido/completion/availability de una mod_page existente.',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'services'     => ['validanet_api'],
    ],
    'local_validanet_create_resource_with_file' => [
        'classname'    => 'local_validanet\\external\\create_resource_with_file',
        'methodname'   => 'execute',
        'description'  => 'Sube un archivo (base64) y crea una mod_resource en una sección. Útil para rúbricas PDF.',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'services'     => ['validanet_api'],
    ],
    'local_validanet_debug_read_quiz_questions' => [
        'classname'    => 'local_validanet\\external\\debug_read_quiz_questions',
        'methodname'   => 'execute',
        'description'  => 'DEBUG: lee las preguntas crudas de un quiz.',
        'type'         => 'read',
        'capabilities' => 'mod/quiz:manage',
        'services'     => ['validanet_api'],
    ],
    'local_validanet_debug_read_feedback_item' => [
        'classname'    => 'local_validanet\\external\\debug_read_feedback_item',
        'methodname'   => 'execute',
        'description'  => 'DEBUG: lee la fila cruda de feedback_item.',
        'type'         => 'read',
        'capabilities' => 'mod/feedback:edititems',
        'services'     => ['validanet_api'],
    ],
    'local_validanet_add_quiz_questions_json' => [
        'classname'    => 'local_validanet\\external\\add_quiz_questions_json',
        'methodname'   => 'execute',
        'description'  => 'Crea preguntas en un quiz desde JSON (esquema Builder IA), sin GIFT.',
        'type'         => 'write',
        'capabilities' => 'mod/quiz:manage, moodle/question:add',
        'services'     => ['validanet_api'],
    ],
    'local_validanet_delete_modules' => [
        'classname'    => 'local_validanet\\external\\delete_modules',
        'methodname'   => 'execute',
        'description'  => 'Borra una lista de course_modules por cmid (cleanup).',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'services'     => ['validanet_api'],
    ],
    'local_validanet_create_h5p_activity' => [
        'classname'    => 'local_validanet\\external\\create_h5p_activity',
        'methodname'   => 'execute',
        'description'  => 'Empaqueta content.json+h5p.json como .h5p y crea mod_h5pactivity.',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities, mod/h5pactivity:addinstance',
        'services'     => ['validanet_api'],
    ],
    'local_validanet_update_module_availability' => [
        'classname'    => 'local_validanet\\external\\update_module_availability',
        'methodname'   => 'execute',
        'description'  => 'Actualiza availability_json de un course_module. Útil para restricciones cross-módulo post-deploy.',
        'type'         => 'write',
        'capabilities' => 'moodle/course:manageactivities',
        'services'     => ['validanet_api'],
    ],
];
