<?php
/**
 * Upgrades para local_validanet.
 *
 * Moodle ejecuta esta función al actualizar el plugin (cuando version.php
 * incrementa). Aprovechamos para:
 *   1. Reconciliar funciones del servicio web "ValidaNet API" (db/services.php
 *      lo hace automáticamente para el servicio en sí, pero NO siempre
 *      garantiza el orden cuando la función no existía en la versión anterior).
 *   2. Asegurar que webservices/REST están habilitados a nivel global (las
 *      capabilities están bien pero a veces el admin deshabilita el subsistema).
 *   3. Auto-agregar tool_mobile_get_autologin_key al servicio existente para
 *      habilitar SSO desde CampusStore (alumno entra directo al curso sin
 *      login manual). Requiere version >= 1.5.0 (2026051600).
 */
defined('MOODLE_INTERNAL') || die();

function xmldb_local_validanet_upgrade($oldversion) {
    global $CFG, $DB;

    // ── 1.5.0 (2026051600) — Funciones SSO + reconciliación ─────────────
    if ($oldversion < 2026051600) {
        _local_validanet_ensure_webservices_enabled();
        _local_validanet_add_functions_to_service([
            // SSO autologin: el alumno entra al curso sin login manual.
            'tool_mobile_get_autologin_key',
            'tool_mobile_get_public_config',
            'auth_email_get_signup_settings',
        ]);
        upgrade_plugin_savepoint(true, 2026051600, 'local', 'validanet');
    }

    // ── 1.6.1 (2026051805) — Courses AI Builder: funciones escritura ────
    if ($oldversion < 2026051805) {
        _local_validanet_ensure_webservices_enabled();
        _local_validanet_add_functions_to_service([
            // Curso skeleton + secciones + categorías
            'core_course_create_courses',
            'core_course_update_courses',
            'core_course_delete_courses',
            'core_course_edit_section',
            'core_course_create_categories',
            'core_course_get_course_module',
            // Archivos
            'core_files_upload',
            'core_files_get_files',
            // Roles (tutor académico + administrativo)
            'core_role_assign_roles',
            'core_role_unassign_roles',
            // Glosario por módulo
            'mod_glossary_get_glossaries_by_courses',
            'mod_glossary_add_entry',
            // Cuestionarios
            'mod_quiz_save_questions',
            // Foros
            'mod_forum_add_discussion',
            // Encuesta satisfacción
            'mod_feedback_get_feedback_access_information',
            'mod_feedback_get_feedbacks_by_courses',
            // H5P (Moodle 4.x core)
            'core_h5p_get_trusted_h5p_file',
            'mod_h5pactivity_get_h5pactivity_access_information',
            'mod_h5pactivity_get_h5pactivities_by_courses',
            'mod_h5pactivity_get_user_attempts',
        ]);
        // Habilitar uploadfiles=1 en el servicio (necesario para SCORM/H5P)
        _local_validanet_enable_service_upload();
        upgrade_plugin_savepoint(true, 2026051805, 'local', 'validanet');
    }

    return true;
}


/**
 * Habilita uploadfiles=1 en el servicio "validanet_api" para permitir
 * subir paquetes SCORM/H5P y archivos del curso vía core_files_upload.
 */
function _local_validanet_enable_service_upload(): void {
    global $DB;
    $service = $DB->get_record('external_services', ['shortname' => 'validanet_api']);
    if ($service && intval($service->uploadfiles) !== 1) {
        $DB->set_field('external_services', 'uploadfiles', 1, ['id' => $service->id]);
        mtrace("[local_validanet] upgrade: uploadfiles=1 habilitado en validanet_api");
    }
}


/**
 * Asegura que el subsistema de webservices y el protocolo REST están activos.
 * Si el admin los deshabilitó, los activa de nuevo (idempotente y silencioso).
 */
function _local_validanet_ensure_webservices_enabled(): void {
    set_config('enablewebservices', 1);
    $protocols = get_config(null, 'webserviceprotocols') ?: '';
    if (strpos((string) $protocols, 'rest') === false) {
        set_config(
            'webserviceprotocols',
            trim(($protocols ? $protocols . ',' : '') . 'rest', ',')
        );
    }
    // Permitir character set extendido para usernames tipo RUT (18123456-k)
    set_config('extendedusernamechars', 1);
}


/**
 * Agrega las funciones indicadas al servicio externo "validanet_api"
 * (shortname). Si el servicio no existe, lo crea. Idempotente: ignora
 * funciones ya presentes.
 *
 * Esta lógica complementa db/services.php (que Moodle reconcilia en upgrade)
 * pero es más explícita y nos permite loguear el resultado.
 */
function _local_validanet_add_functions_to_service(array $functions): void {
    global $DB;

    $shortname = 'validanet_api';
    $service   = $DB->get_record('external_services', ['shortname' => $shortname]);
    if (!$service) {
        // db/services.php debería haberlo creado en el upgrade del plugin;
        // si por alguna razón no existe, lo creamos como fallback.
        $service = (object) [
            'name'            => 'ValidaNet API',
            'shortname'       => $shortname,
            'enabled'         => 1,
            'restrictedusers' => 0,
            'downloadfiles'   => 1,
            'uploadfiles'     => 0,
            'timecreated'     => time(),
        ];
        $service->id = $DB->insert_record('external_services', $service);
    }

    $added = 0;
    foreach ($functions as $fname) {
        $exists = $DB->record_exists('external_services_functions', [
            'externalserviceid' => $service->id,
            'functionname'      => $fname,
        ]);
        if (!$exists) {
            $DB->insert_record('external_services_functions', [
                'externalserviceid' => $service->id,
                'functionname'      => $fname,
            ]);
            $added++;
        }
    }
    mtrace("[local_validanet] upgrade: añadidas {$added} funciones al servicio '{$shortname}'");
}
