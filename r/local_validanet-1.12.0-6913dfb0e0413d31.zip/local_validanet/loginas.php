<?php
/**
 * local_validanet/loginas.php — Entrar como alumno en modo soporte.
 *
 * Replica el comportamiento nativo de Moodle "Login as" (Site admin →
 * Browse users → Login as): la sesión queda marcada como `loggedinas`,
 * lo que hace que Moodle NO registre completion, intentos de quiz, grades
 * ni posts en foros como acciones del alumno target.
 *
 * Invocado desde el panel ValidaNet con URL firmada (HMAC del gateway_key):
 *   /local/validanet/loginas.php?u=<target_userid>&ts=<epoch>&sig=<hex>
 *
 * Validación:
 *   - El admin que abre la URL debe estar logueado en este Moodle con
 *     capability moodle/user:loginas en system context (admins por defecto).
 *   - ts debe estar dentro de una ventana de 5 minutos.
 *   - sig = hmac_sha256(gateway_key, "{u}:{ts}").
 *
 * Tras loginas exitoso, redirect al course/view.php?id=... si se pasó
 * `course`, o al /my de Moodle.
 */
require_once(__DIR__ . '/../../config.php');

$u      = required_param('u',  PARAM_INT);
$ts     = required_param('ts', PARAM_INT);
$sig    = required_param('sig', PARAM_ALPHANUMEXT);
$course = optional_param('course', 0, PARAM_INT);

require_login();
require_capability('moodle/user:loginas', context_system::instance());

// Ventana anti-replay: 5 minutos.
// Moodle 4.x removió print_error() — usamos moodle_exception con string key
// del lang (lang/es/local_validanet.php) y mensaje fallback via debuginfo.
$now = time();
if (abs($now - $ts) > 300) {
    throw new moodle_exception('expired', 'local_validanet', '', null,
        'El enlace expiró. Vuelve al panel ValidaNet y genera uno nuevo.');
}

// Validar HMAC contra gateway_key del plugin.
$gwkey = get_config('local_validanet', 'gateway_key') ?: '';
if (!$gwkey) {
    throw new moodle_exception('nogwkey', 'local_validanet', '', null,
        'Plugin sin gateway_key configurada — re-ejecuta el wizard de ValidaNet.');
}
$expected = hash_hmac('sha256', "$u:$ts", $gwkey);
if (!hash_equals($expected, $sig)) {
    throw new moodle_exception('badsig', 'local_validanet', '', null,
        'Firma inválida. La URL fue manipulada o el gateway_key no coincide entre Moodle y ValidaNet.');
}

// Verificar que el usuario target existe y no es admin (no permitimos
// loginas a otro admin — es protección estándar de Moodle).
$target = $DB->get_record('user', ['id' => $u, 'deleted' => 0], '*', MUST_EXIST);
if (is_siteadmin($target)) {
    throw new moodle_exception('nologinasadmin', 'local_validanet', '', null,
        'No se permite "Entrar como" a otro administrador del sitio.');
}

// Determinar contexto del loginas:
//   - Si course != 0 y el usuario está enrolado, usar ese context.
//   - Sino, system context (loginas global).
$context = context_system::instance();
$redir_url = new moodle_url('/my/');
if ($course) {
    $course_ctx = context_course::instance($course, IGNORE_MISSING);
    if ($course_ctx && is_enrolled($course_ctx, $target)) {
        $context = $course_ctx;
        $redir_url = new moodle_url('/course/view.php', ['id' => $course]);
    }
}

// Esta es la magia: \core\session\manager::loginas() setea
// $SESSION->userid (admin original) + $USER (target), marcando la
// sesión como "loggedinas". A partir de aquí, Moodle ignora completion,
// grades, posts, intentos de quiz, etc. para este alumno — exactamente
// lo que pidió el cliente.
\core\session\manager::loginas($u, $context);

// Logueo evento para auditoría (igual que Moodle nativo lo hace).
$event = \core\event\user_loggedinas::create([
    'objectid' => $u,
    'context'  => $context,
    'other'    => [
        'originalusername' => fullname($USER->realuser ? $DB->get_record('user', ['id' => $USER->realuser]) : $USER),
        'loggedinasusername' => fullname($target),
    ],
]);
$event->trigger();

redirect($redir_url, '👁️ Modo soporte ValidaNet — tus acciones NO se registran como del alumno.', 2);
