<?php
defined('MOODLE_INTERNAL') || die();

// Legacy gateway_key compartido — todos los plugins instalados antes de
// 2026-05-15 usan este default. Auto-rotación per-client implementada
// abajo en _local_validanet_maybe_rotate_gateway().
const LOCAL_VALIDANET_LEGACY_GATEWAY = 'vn-gw-2026-norteduc-plugin-secret';

function local_validanet_after_install() {
    set_config('wizard_done', 0, 'local_validanet');
}

function local_validanet_after_config() {
    global $CFG, $PAGE;
    if (!isloggedin() || !is_siteadmin()) return;
    if (!isset($PAGE) || !$PAGE->url) return;

    $wizard_done = get_config('local_validanet', 'wizard_done');

    if (!$wizard_done) {
        // Wizard pendiente → redirigir admin a la configuración inicial.
        $current = $PAGE->url->out(false);
        $trigger = ['upgradesettings', '/admin/index.php', '/admin/settings.php'];
        foreach ($trigger as $t) {
            if (strpos($current, $t) !== false) {
                redirect(new moodle_url($CFG->wwwroot . '/local/validanet/wizard.php'));
                return;
            }
        }
        return;
    }

    // Wizard completado → revisar si el gateway_key sigue siendo el legacy
    // compartido y rotar a uno per-cliente. Solo se intenta una vez al día.
    _local_validanet_maybe_rotate_gateway();
}

/**
 * Auto-rotación gateway_key (2026-05-15):
 * Si la clave local es el legacy default compartido publicado en el repo,
 * pedir al backend ValidaNet una clave per-cliente y guardarla. Solo corre
 * 1 vez al día por admin (cache via plugin config) para evitar spam.
 */
function _local_validanet_maybe_rotate_gateway() {
    $gwkey = get_config('local_validanet', 'gateway_key') ?: '';
    if ($gwkey && $gwkey !== LOCAL_VALIDANET_LEGACY_GATEWAY) {
        return; // ya rotado
    }

    // Throttle: 1 intento cada 24h.
    $last_try = (int) (get_config('local_validanet', 'gw_rotate_last') ?: 0);
    if ((time() - $last_try) < 86400) return;
    set_config('gw_rotate_last', time(), 'local_validanet');

    $apikey = get_config('local_validanet', 'apikey') ?: '';
    $apiurl = get_config('local_validanet', 'apiurl') ?: 'https://app.validanet.cl';
    if (!$apikey) return;

    $present_gw = $gwkey ?: LOCAL_VALIDANET_LEGACY_GATEWAY;
    $ch = curl_init(rtrim($apiurl, '/') . '/api/plugin/rotate-gateway');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => '{}',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 5,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apikey,
            'X-TutorIA-API-Key: ' . $present_gw,
        ],
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($code === 200) {
        $data = @json_decode($resp, true);
        if (!empty($data['gateway_key'])
            && $data['gateway_key'] !== LOCAL_VALIDANET_LEGACY_GATEWAY) {
            set_config('gateway_key', $data['gateway_key'], 'local_validanet');
            set_config('gw_rotate_ok_at', time(), 'local_validanet');
        }
    }
    // Silencioso ante fallos: se reintenta mañana.
}
