<?php
defined('MOODLE_INTERNAL') || die();
if ($hassiteconfig) {
    $settings = new admin_settingpage('local_validanet', 'ValidaNet');

    if (!get_config('local_validanet', 'wizard_done')) {
        // Mostrar botón al wizard en lugar de redirigir
        $wizard_url = new moodle_url('/local/validanet/wizard.php');
        $settings->add(new admin_setting_heading(
            'local_validanet/wizard_notice',
            '🚀 Configuración inicial requerida',
            '<div style="background:#d1ecf1;border:1px solid #bee5eb;border-radius:8px;padding:20px;margin:10px 0;">
                <p style="font-size:15px;margin-bottom:16px;">
                    El plugin ValidaNet necesita configurarse antes de usarse.<br>
                    El asistente te guiará paso a paso en menos de 5 minutos.
                </p>
                <a href="'.$wizard_url.'" class="btn btn-primary btn-lg" 
                   style="background:#0d6efd;color:white;padding:10px 24px;
                          border-radius:6px;text-decoration:none;font-weight:600;">
                    ⚡ Abrir asistente de configuración →
                </a>
            </div>'
        ));
    } else {
        $settings->add(new admin_setting_heading(
            'local_validanet/status',
            '✅ ValidaNet configurado',
            '<div style="background:#d4edda;border:1px solid #c3e6cb;border-radius:8px;padding:12px;">
                Plugin conectado correctamente con ValidaNet.
                <a href="/local/validanet/wizard.php" style="margin-left:12px;">Reconfigurar</a>
            </div>'
        ));
    }

    $settings->add(new admin_setting_configtext(
        'local_validanet/apikey',
        'API Key ValidaNet',
        'Obtenla en app.validanet.cl → Configuración → Credenciales', ''));
    $settings->add(new admin_setting_configtext(
        'local_validanet/apiurl',
        'URL API ValidaNet', '', 'https://app.validanet.cl'));
    $settings->add(new admin_setting_configtext(
        'local_validanet/moodle_token',
        'Token Moodle Web Services',
        'Generado en Moodle → Servidor → Servicios Web → Tokens', ''));

    $settings->add(new admin_setting_heading(
        'local_validanet/autoupdate_heading',
        '⚡ Auto-update de plugins ValidaNet',
        'Permite que los plugins ValidaNet (local_validanet y block_validanet) se '
        . 'actualicen automáticamente cada 6 horas consultando el feed oficial de '
        . 'app.validanet.cl. Sin intervención manual del admin tras habilitarlo.'
    ));
    $settings->add(new admin_setting_configcheckbox(
        'local_validanet/auto_update_enabled',
        'Auto-update habilitado',
        'Al habilitarlo, la tarea "ValidaNet — auto-update de plugins" descargará e '
        . 'instalará nuevas versiones automáticamente. Requiere que el usuario que '
        . 'corre cron tenga permisos de escritura sobre el directorio de Moodle. '
        . '<strong>Recomendado para sitios gestionados por NortEduc.</strong>',
        0
    ));

    $ADMIN->add('localplugins', $settings);
}
