<?php
// Scheduled task que descarga e instala automáticamente nuevas versiones
// de los plugins ValidaNet (local_validanet, block_validanet) desde el
// feed Moodle Update API 1.3 publicado en app.validanet.cl.
//
// Gateada por setting `local_validanet | auto_update_enabled` (default off
// para que el admin opte explícitamente — instalar código sin supervisión
// debe ser una decisión consciente).
//
// Flujo: consulta feed → compara versiones → descarga ZIP → valida MD5 →
// instala vía core_plugin_manager → corre upgrade_noncore() para aplicar
// migraciones SQL del plugin.

namespace local_validanet\task;

defined('MOODLE_INTERNAL') || die();

class auto_update_task extends \core\task\scheduled_task {

    public function get_name() {
        return 'ValidaNet — auto-update de plugins';
    }

    public function execute() {
        global $CFG;

        if (!get_config('local_validanet', 'auto_update_enabled')) {
            mtrace('[validanet auto-update] deshabilitado (setting auto_update_enabled=off)');
            return;
        }
        $apiurl = get_config('local_validanet', 'apiurl') ?: 'https://app.validanet.cl';
        $feed_url = rtrim($apiurl, '/') . '/api/moodle/plugin-updates';

        // 1) Consultar feed
        $ch = curl_init($feed_url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_HTTPHEADER     => ['Accept: application/json'],
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code !== 200 || !$body) {
            mtrace("[validanet auto-update] feed http=$code — abortando");
            return;
        }
        $feed = json_decode($body, true);
        if (!is_array($feed) || empty($feed['plugins'])) {
            mtrace('[validanet auto-update] feed inválido o vacío');
            return;
        }

        // 2) Detectar plugins ValidaNet instalados con su versión actual
        $dir_map = ['local' => 'local', 'block' => 'blocks'];
        $installable = [];
        foreach ($feed['plugins'] as $entry) {
            $comp = $entry['component'] ?? '';
            if (!in_array($comp, ['local_validanet', 'block_validanet'], true)) continue;
            $branch = $entry['branches']['main'][0] ?? null;
            if (!$branch) continue;
            $remote_version = (int) ($branch['version'] ?? 0);
            $download_url   = (string) ($branch['downloadurl'] ?? '');
            $download_md5   = (string) ($branch['downloadmd5'] ?? '');
            if (!$remote_version || !$download_url || !$download_md5) continue;

            // Versión actual instalada
            $type = strtok($comp, '_');
            $name = substr($comp, strlen($type) + 1);
            $dir  = $dir_map[$type] ?? $type;
            $vfile = $CFG->dirroot . '/' . $dir . '/' . $name . '/version.php';
            if (!is_readable($vfile)) {
                mtrace("[validanet auto-update] $comp no instalado — skip");
                continue;
            }
            $plugin = new \stdClass();
            include($vfile);
            $local_version = (int) ($plugin->version ?? 0);

            if ($remote_version <= $local_version) {
                mtrace("[validanet auto-update] $comp ya en v$local_version (remoto v$remote_version) — skip");
                continue;
            }

            mtrace("[validanet auto-update] $comp: $local_version → $remote_version (release {$branch['release']})");
            $info = new \stdClass();
            $info->component   = $comp;
            $info->version     = $remote_version;
            $info->release     = (string) ($branch['release'] ?? '');
            $info->maturity    = (int) ($branch['maturity'] ?? 200);
            $info->downloadurl = $download_url;
            $info->downloadmd5 = $download_md5;
            $installable[] = $info;
        }

        if (empty($installable)) {
            mtrace('[validanet auto-update] todo al día');
            return;
        }

        // 3) Aplicar updates vía core_plugin_manager
        // install_plugins() descarga ZIP, valida MD5, extrae a directorio
        // de plugins y deja a Moodle correr las migraciones. Requiere que
        // $CFG->dirroot sea writable por el usuario que corre cron.
        require_once($CFG->libdir . '/upgradelib.php');
        $pluginman = \core_plugin_manager::instance();
        if (!method_exists($pluginman, 'install_plugins')) {
            mtrace('[validanet auto-update] install_plugins() no disponible en esta versión de Moodle');
            return;
        }
        try {
            $ok = $pluginman->install_plugins($installable, true /*confirmed*/, true /*silent*/);
        } catch (\Throwable $e) {
            mtrace('[validanet auto-update] excepción install_plugins: ' . $e->getMessage());
            return;
        }
        if ($ok === false) {
            mtrace('[validanet auto-update] install_plugins devolvió false — revisar permisos en ' . $CFG->dirroot);
            return;
        }

        // 4) Aplicar upgrade no-core para correr migraciones SQL del plugin.
        // upgrade_noncore() es idempotente y bumpea $plugin->version en mdl_config_plugins.
        try {
            upgrade_noncore(false /*verbose*/);
        } catch (\Throwable $e) {
            mtrace('[validanet auto-update] upgrade_noncore excepción: ' . $e->getMessage());
            return;
        }

        $names = array_map(function($i){ return $i->component . '→' . $i->release; }, $installable);
        mtrace('[validanet auto-update] OK — actualizado: ' . implode(', ', $names));

        // 5) Limpiar cachés para que cambios sean inmediatos sin browse-admin
        try {
            \purge_all_caches();
        } catch (\Throwable $e) {
            // no crítico
        }
    }
}
