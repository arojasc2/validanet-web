<?php
// Scheduled task que sincroniza la lista de cursos + contenido desde Moodle
// hacia ValidaNet. Permite que el dashboard CampusStore tenga los cursos
// indexados sin esperar a que un alumno inicie un chat, y que el AI-fill
// pueda generar texto basado en el contenido real del curso.

namespace local_validanet\task;

defined('MOODLE_INTERNAL') || die();

class sync_courses_task extends \core\task\scheduled_task {

    public function get_name() {
        return 'ValidaNet — sync de cursos y contenido';
    }

    public function execute() {
        $apikey = get_config('local_validanet', 'apikey') ?: '';
        $apiurl = get_config('local_validanet', 'apiurl') ?: 'https://app.validanet.cl';
        if (!$apikey) {
            mtrace('[validanet sync-courses] omitido: apikey no configurada');
            return;
        }

        $ch = curl_init(rtrim($apiurl, '/') . '/api/validanet/moodle/sync-courses?deep=true');
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => '{}',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 120,
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $apikey,
            ],
        ]);
        $resp = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($code === 200) {
            $data = json_decode((string) $resp, true) ?: [];
            $synced      = $data['synced']      ?? '?';
            $deep        = $data['deep_synced'] ?? 0;
            $total       = $data['total_moodle'] ?? '?';
            mtrace("[validanet sync-courses] OK — synced={$synced}/{$total}, deep_content={$deep}");
        } else {
            mtrace('[validanet sync-courses] FALLO HTTP ' . $code . ' resp=' . substr((string) $resp, 0, 200));
        }
    }
}
