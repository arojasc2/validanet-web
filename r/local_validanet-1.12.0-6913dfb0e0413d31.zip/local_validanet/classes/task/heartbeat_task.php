<?php
// Scheduled task que reporta diariamente a ValidaNet qué versión de los
// plugins ValidaNet está instalada, qué release de Moodle corre el sitio
// y la URL de la instalación. Sirve a app.validanet.cl para:
//   1) Mostrar a operadores qué clientes están al día.
//   2) Mandar email cuando un cliente está >7 días atrás de la release
//      publicada en /api/moodle/plugin-updates.

namespace local_validanet\task;

defined('MOODLE_INTERNAL') || die();

class heartbeat_task extends \core\task\scheduled_task {

    public function get_name() {
        return 'ValidaNet — heartbeat de versiones';
    }

    public function execute() {
        global $CFG, $DB;

        $apikey = get_config('local_validanet', 'apikey') ?: '';
        $apiurl = get_config('local_validanet', 'apiurl') ?: 'https://app.validanet.cl';
        if (!$apikey) {
            mtrace('[validanet heartbeat] omitido: apikey no configurada');
            return;
        }

        // Componentes ValidaNet a reportar — buscamos los version.php de
        // cada uno y leemos sus campos $plugin->version y $plugin->release.
        // Antes computábamos "$type/$name" → para block_validanet daba
        // "block/validanet" (path inexistente; Moodle usa "blocks/" plural)
        // y el heartbeat omitía silenciosamente reportar block_validanet.
        $dir_map = [
            'local' => 'local',
            'block' => 'blocks',
            'mod'   => 'mod',
            'theme' => 'theme',
        ];
        $components = ['local_validanet', 'block_validanet'];
        $reported = [];
        foreach ($components as $comp) {
            $type   = strtok($comp, '_');           // 'local' o 'block'
            $name   = substr($comp, strlen($type) + 1);
            $dir    = $dir_map[$type] ?? $type;
            $vfile  = $CFG->dirroot . '/' . $dir . '/' . $name . '/version.php';
            if (!is_readable($vfile)) continue;
            $plugin = new \stdClass();
            include($vfile); // popula $plugin->version y ->release
            if (!empty($plugin->version) && !empty($plugin->release)) {
                $reported[] = [
                    'component' => $comp,
                    'version'   => (int) $plugin->version,
                    'release'   => (string) $plugin->release,
                ];
            }
        }

        $payload = json_encode([
            'plugins'        => $reported,
            'moodle_release' => $CFG->release ?? '',
            'site_url'       => $CFG->wwwroot,
        ]);

        $ch = curl_init(rtrim($apiurl, '/') . '/api/moodle/plugin-heartbeat');
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $payload,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $apikey,
            ],
        ]);
        $resp = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($code === 200) {
            mtrace('[validanet heartbeat] OK — reportados: ' .
                   implode(', ', array_column($reported, 'component')));
        } else {
            mtrace('[validanet heartbeat] FALLO HTTP ' . $code . ' resp=' . substr((string) $resp, 0, 200));
        }
    }
}
