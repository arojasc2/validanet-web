<?php
// Función WS: local_validanet_create_h5p_activity
// Recibe content.json + h5p.json (manifest), empaqueta como .h5p ZIP,
// sube al área de borradores del WS user, y crea una mod_h5pactivity
// referenciando el archivo. Las librerías H5P referenciadas en h5p.json
// deben estar instaladas en el Moodle del cliente.

namespace local_validanet\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;
use context_course;
use context_user;
use stdClass;
use invalid_parameter_exception;
use ZipArchive;

class create_h5p_activity extends external_api {

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'courseid'    => new external_value(PARAM_INT, 'ID del curso'),
            'section'     => new external_value(PARAM_INT, 'Número de sección'),
            'name'        => new external_value(PARAM_TEXT, 'Nombre de la actividad'),
            'intro'       => new external_value(PARAM_RAW, 'Intro HTML', VALUE_DEFAULT, ''),
            'content_json' => new external_value(PARAM_RAW, 'H5P content.json (string)'),
            'h5p_json'    => new external_value(PARAM_RAW, 'H5P manifest h5p.json (string)'),
            'visible'     => new external_value(PARAM_BOOL, 'Visible', VALUE_DEFAULT, true),
            'completion'  => new external_value(PARAM_INT, '0/1/2', VALUE_DEFAULT, 0),
            'completionview' => new external_value(PARAM_BOOL, '', VALUE_DEFAULT, false),
            'completionusegrade' => new external_value(PARAM_BOOL, '', VALUE_DEFAULT, false),
            'completionpassgrade' => new external_value(PARAM_BOOL, '', VALUE_DEFAULT, false),
            'availability_json' => new external_value(PARAM_RAW, '', VALUE_DEFAULT, ''),
            'enabletracking' => new external_value(PARAM_BOOL, 'xAPI tracking', VALUE_DEFAULT, true),
            'grade'       => new external_value(PARAM_FLOAT, 'Escala de nota (default 100)', VALUE_DEFAULT, 100.0),
            'images_b64_json' => new external_value(PARAM_RAW,
                'JSON: {"filename.png":"<base64>","..."}. Se agregan en content/images/ del .h5p ZIP.',
                VALUE_DEFAULT, ''),
        ]);
    }

    public static function execute(int $courseid, int $section, string $name,
                                    string $intro, string $content_json,
                                    string $h5p_json, bool $visible = true,
                                    int $completion = 0,
                                    bool $completionview = false,
                                    bool $completionusegrade = false,
                                    bool $completionpassgrade = false,
                                    string $availability_json = '',
                                    bool $enabletracking = true,
                                    float $grade = 100.0,
                                    string $images_b64_json = ''): array {
        global $DB, $CFG, $USER;
        require_once($CFG->dirroot . '/course/lib.php');
        require_once($CFG->dirroot . '/course/modlib.php');
        require_once($CFG->libdir . '/filelib.php');

        $params = self::validate_parameters(self::execute_parameters(), [
            'courseid' => $courseid, 'section' => $section, 'name' => $name,
            'intro' => $intro, 'content_json' => $content_json, 'h5p_json' => $h5p_json,
            'visible' => $visible, 'completion' => $completion,
            'completionview' => $completionview,
            'completionusegrade' => $completionusegrade,
            'completionpassgrade' => $completionpassgrade,
            'availability_json' => $availability_json,
            'enabletracking' => $enabletracking, 'grade' => $grade,
            'images_b64_json' => $images_b64_json,
        ]);

        $context = context_course::instance($params['courseid']);
        self::validate_context($context);
        require_capability('moodle/course:manageactivities', $context);
        require_capability('mod/h5pactivity:addinstance', $context);

        // 1) Validar JSONs parseables
        $content_decoded = json_decode($params['content_json'], true);
        $h5p_decoded = json_decode($params['h5p_json'], true);
        if (!is_array($content_decoded)) {
            throw new invalid_parameter_exception('content_json no es JSON válido');
        }
        if (!is_array($h5p_decoded) || empty($h5p_decoded['mainLibrary'])) {
            throw new invalid_parameter_exception('h5p_json no es válido (falta mainLibrary)');
        }

        // 2) Empaquetar .h5p ZIP en tmp
        $tmpfile = tempnam(sys_get_temp_dir(), 'vn_h5p_') . '.h5p';
        $zip = new ZipArchive();
        if ($zip->open($tmpfile, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            @unlink($tmpfile);
            throw new \Exception('No se pudo crear el ZIP .h5p temporal');
        }
        $zip->addFromString('h5p.json', $params['h5p_json']);
        $zip->addFromString('content/content.json', $params['content_json']);
        // Imágenes opcionales: se agregan en content/images/
        if (!empty($params['images_b64_json'])) {
            $images = json_decode($params['images_b64_json'], true);
            if (is_array($images)) {
                foreach ($images as $imgname => $b64) {
                    $clean = basename((string) $imgname);
                    if (empty($clean) || strpbrk($clean, "\0\r\n/\\") !== false) {
                        continue; // path traversal defense
                    }
                    $img_bytes = base64_decode((string) $b64, true);
                    if ($img_bytes === false) continue;
                    if (strlen($img_bytes) > 4 * 1024 * 1024) continue; // hard cap 4MB por imagen
                    $zip->addFromString("content/images/{$clean}", $img_bytes);
                }
            }
        }
        $zip->close();
        $content_bytes = file_get_contents($tmpfile);
        @unlink($tmpfile);
        if ($content_bytes === false || strlen($content_bytes) < 50) {
            throw new \Exception('El archivo .h5p generado está vacío o corrupto');
        }

        // 3) Subir el .h5p al área draft del WS user
        $usercontext = context_user::instance($USER->id);
        $draftitemid = file_get_unused_draft_itemid();
        $fs = get_file_storage();
        $filerec = (object) [
            'contextid' => $usercontext->id,
            'component' => 'user',
            'filearea'  => 'draft',
            'itemid'    => $draftitemid,
            'filepath'  => '/',
            'filename'  => 'activity.h5p',
            'timecreated'  => time(),
            'timemodified' => time(),
            'mimetype'  => 'application/zip',
            'userid'    => $USER->id,
        ];
        $fs->create_file_from_string($filerec, $content_bytes);

        // 4) Crear mod_h5pactivity vía add_moduleinfo
        $course = get_course($params['courseid']);
        $module = $DB->get_record('modules', ['name' => 'h5pactivity'], '*', MUST_EXIST);
        course_create_sections_if_missing($course, [$params['section']]);

        $moduleinfo = new stdClass();
        $moduleinfo->course             = $course->id;
        $moduleinfo->module             = $module->id;
        $moduleinfo->modulename         = 'h5pactivity';
        $moduleinfo->section            = $params['section'];
        $moduleinfo->name               = trim($params['name']);
        $moduleinfo->visible            = $params['visible'] ? 1 : 0;
        $moduleinfo->visibleoncoursepage = 1;
        $moduleinfo->intro              = $params['intro'] ?: ' ';
        $moduleinfo->introformat        = FORMAT_HTML;
        $moduleinfo->cmidnumber         = '';
        $moduleinfo->groupmode          = 0;
        $moduleinfo->groupingid         = 0;
        $moduleinfo->showdescription    = empty($params['intro']) ? 0 : 1;

        // Completion (course_modules)
        $moduleinfo->completion         = (int) $params['completion'];
        if ($params['completionview']) {
            $moduleinfo->completionview = 1;
        }
        if ($params['completionusegrade']) {
            $moduleinfo->completionusegrade = 1;
            $moduleinfo->completiongradeitemnumber = 0;
        }
        if ($params['completionpassgrade']) {
            $moduleinfo->completionpassgrade = 1;
        }
        if (!empty($params['availability_json'])) {
            $moduleinfo->availability = $params['availability_json'];
        }

        // h5pactivity-specific fields
        $moduleinfo->packagefile        = $draftitemid;
        $moduleinfo->displayoptions     = 0;
        $moduleinfo->enabletracking     = $params['enabletracking'] ? 1 : 0;
        $moduleinfo->grademethod        = 1; // GRADEHIGHESTATTEMPT
        $moduleinfo->reviewmode         = 1; // Mostrar intentos tras completion
        $moduleinfo->grade              = (float) $params['grade'];

        try {
            $created = add_moduleinfo($moduleinfo, $course);
        } catch (\Throwable $e) {
            $parts = [get_class($e)];
            if (property_exists($e, 'errorcode') && $e->errorcode) {
                $parts[] = 'code=' . $e->errorcode;
            }
            $parts[] = 'msg=' . $e->getMessage();
            if (method_exists($e, 'getDebugInfo')) {
                $di = $e->getDebugInfo();
                if ($di) $parts[] = 'debug=' . $di;
            }
            if (property_exists($e, 'error') && !empty($e->error)) {
                $parts[] = 'sql_error=' . $e->error;
            }
            error_log('local_validanet_create_h5p_activity failed: ' . implode(' | ', $parts));
            throw new \Exception('create_h5p_activity add_moduleinfo failed: '
                . mb_substr(implode(' | ', $parts), 0, 900, 'UTF-8'));
        }

        error_log(sprintf('[validanet_audit] user=%d action=create_h5p_activity '
            . 'course=%d section=%d cmid=%d library=%s',
            $USER->id, $params['courseid'], $params['section'],
            (int) $created->coursemodule, $h5p_decoded['mainLibrary']));

        return [
            'ok'         => true,
            'cmid'       => (int) $created->coursemodule,
            'instanceid' => (int) $created->instance,
            'section'    => (int) $params['section'],
            'library'    => mb_substr((string) $h5p_decoded['mainLibrary'], 0, 100, 'UTF-8'),
        ];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'ok'         => new external_value(PARAM_BOOL, ''),
            'cmid'       => new external_value(PARAM_INT, ''),
            'instanceid' => new external_value(PARAM_INT, ''),
            'section'    => new external_value(PARAM_INT, ''),
            'library'    => new external_value(PARAM_TEXT, 'mainLibrary H5P del paquete'),
        ]);
    }
}
