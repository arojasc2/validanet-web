<?php
// Función WS: local_validanet_set_feedback_items
// Reemplaza los items de una mod_feedback (encuesta) con una lista nueva.
// Soporta types: label, textfield, textarea, multichoice, multichoicerated,
// numeric, pagebreak.

namespace local_validanet\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;
use core_external\external_multiple_structure;
use context_module;
use stdClass;
use invalid_parameter_exception;

class set_feedback_items extends external_api {

    private const ITEM_TYPES = [
        'label', 'textfield', 'textarea', 'multichoice', 'multichoicerated',
        'numeric', 'pagebreak',
    ];
    // Hardening v1.10
    private const MAX_ITEMS = 100;

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid'       => new external_value(PARAM_INT, 'course_modules.id de la mod_feedback'),
            'items_json' => new external_value(PARAM_RAW, 'JSON array de items. Schema:
[{
  "type": "label|textfield|textarea|multichoice|multichoicerated|numeric|pagebreak",
  "name": "Texto de la pregunta o label HTML",
  "label": "etiqueta corta opcional",
  "required": true|false,
  // Type-specific:
  "options": ["Excelente","Bueno","Regular","Malo","Pésimo"],   // multichoice
  "subtype": "r"|"c"|"d",                                       // multichoice (radio/check/dropdown)
  "rated": [[5,"Excelente"],[4,"Bueno"],...],                   // multichoicerated
  "min": 0, "max": 10,                                          // numeric
  "rows": 5, "cols": 60                                         // textarea
}]'),
            'replace'    => new external_value(PARAM_BOOL, 'Borrar items existentes antes (default true)', VALUE_DEFAULT, true),
        ]);
    }

    public static function execute(int $cmid, string $items_json, bool $replace = true): array {
        global $DB, $CFG;
        require_once($CFG->dirroot . '/mod/feedback/lib.php');

        $params = self::validate_parameters(self::execute_parameters(), [
            'cmid' => $cmid, 'items_json' => $items_json, 'replace' => $replace,
        ]);

        $cm = get_coursemodule_from_id('feedback', $params['cmid'], 0, false, MUST_EXIST);
        $context = context_module::instance($cm->id);
        self::validate_context($context);
        require_capability('mod/feedback:edititems', $context);

        $feedback = $DB->get_record('feedback', ['id' => $cm->instance], '*', MUST_EXIST);

        $items = json_decode($params['items_json'], true);
        if (!is_array($items)) {
            throw new invalid_parameter_exception('items_json no es un array JSON válido');
        }
        // Hardening: cap de cantidad de items
        if (count($items) > self::MAX_ITEMS) {
            $items = array_slice($items, 0, self::MAX_ITEMS);
        }
        global $USER;
        error_log(sprintf('[validanet_audit] user=%d action=set_feedback_items '
            . 'cmid=%d items=%d replace=%d',
            $USER->id, $cm->id, count($items), $params['replace'] ? 1 : 0));

        if ($params['replace']) {
            $DB->delete_records('feedback_item', ['feedback' => $feedback->id]);
        }

        $position = (int) $DB->get_field_sql(
            'SELECT COALESCE(MAX(position), 0) FROM {feedback_item} WHERE feedback = ?',
            [$feedback->id]
        );

        $created = [];
        $errors = [];
        foreach ($items as $idx => $spec) {
            if (!is_array($spec) || empty($spec['type'])) {
                $errors[] = ['idx' => $idx, 'error' => 'Falta type'];
                continue;
            }
            $type = $spec['type'];
            if (!in_array($type, self::ITEM_TYPES, true)) {
                $errors[] = ['idx' => $idx, 'error' => "type inválido: $type"];
                continue;
            }
            $position++;
            $item = new stdClass();
            $item->feedback = $feedback->id;
            $item->template = 0;
            $item->name     = mb_substr((string) ($spec['name'] ?? ''), 0, 255, 'UTF-8');
            $item->label    = mb_substr((string) ($spec['label'] ?? ''), 0, 255, 'UTF-8');
            $item->position = $position;
            $item->required = !empty($spec['required']) ? 1 : 0;
            $item->dependitem = 0;
            $item->dependvalue = '';
            $item->options = '';
            $item->typ = $type;

            switch ($type) {
                case 'label':
                    $item->hasvalue = 0;
                    $item->required = 0;
                    $item->presentation = (string) ($spec['name'] ?? '');
                    break;
                case 'pagebreak':
                    $item->hasvalue = 0;
                    $item->required = 0;
                    $item->name = 'pagebreak';
                    $item->presentation = '';
                    break;
                case 'textfield':
                    $item->hasvalue = 1;
                    $w = (int) ($spec['width'] ?? 30);
                    $m = (int) ($spec['maxchars'] ?? 255);
                    $item->presentation = "{$w}|{$m}";
                    break;
                case 'textarea':
                    $item->hasvalue = 1;
                    $cols = (int) ($spec['cols'] ?? 60);
                    $rows = (int) ($spec['rows'] ?? 5);
                    $item->presentation = "{$cols}|{$rows}";
                    break;
                case 'numeric':
                    $item->hasvalue = 1;
                    $min = $spec['min'] ?? '-';
                    $max = $spec['max'] ?? '-';
                    $item->presentation = "{$min}|{$max}";
                    break;
                case 'multichoice':
                    $item->hasvalue = 1;
                    $sub = in_array($spec['subtype'] ?? 'r', ['r','c','d'], true) ? $spec['subtype'] : 'r';
                    $opts = $spec['options'] ?? [];
                    if (!is_array($opts) || empty($opts)) {
                        $errors[] = ['idx' => $idx, 'error' => 'multichoice sin options'];
                        $position--;
                        continue 2;
                    }
                    $hide = !empty($spec['hide_no_select']) ? 1 : 0;
                    // Moodle 4.5: el separador entre opciones es "\n", NO "|" (legacy).
                    $joined = implode("\n", array_map(fn($o) => (string) $o, $opts));
                    $item->presentation = "{$sub}>>>>>{$hide}>>>>>{$joined}";
                    break;
                case 'multichoicerated':
                    $item->hasvalue = 1;
                    $sub = in_array($spec['subtype'] ?? 'r', ['r','c','d'], true) ? $spec['subtype'] : 'r';
                    $rated = $spec['rated'] ?? [];
                    if (!is_array($rated) || empty($rated)) {
                        $errors[] = ['idx' => $idx, 'error' => 'multichoicerated sin rated'];
                        $position--;
                        continue 2;
                    }
                    $hide = !empty($spec['hide_no_select']) ? 1 : 0;
                    $pairs = [];
                    foreach ($rated as $r) {
                        if (is_array($r) && count($r) >= 2) {
                            $pairs[] = ((int) $r[0]) . '####' . (string) $r[1];
                        }
                    }
                    // Moodle 4.5: el separador es "\n", NO "|" (legacy).
                    $joined = implode("\n", $pairs);
                    $item->presentation = "{$sub}>>>>>{$hide}>>>>>{$joined}";
                    break;
            }

            try {
                $item->id = $DB->insert_record('feedback_item', $item);
                $created[] = [
                    'id'   => (int) $item->id,
                    'type' => $type,
                    'name' => mb_substr((string) $item->name, 0, 100, 'UTF-8'),
                    'position' => $position,
                ];
            } catch (\Throwable $e) {
                $errors[] = ['idx' => $idx, 'error' => mb_substr((string)$e->getMessage(), 0, 300, 'UTF-8')];
                $position--;
            }
        }

        return [
            'ok'           => count($created) > 0,
            'items_created' => count($created),
            'items'        => $created,
            'errors'       => $errors,
            'feedback_id'  => (int) $feedback->id,
        ];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'ok'            => new external_value(PARAM_BOOL, ''),
            'items_created' => new external_value(PARAM_INT, ''),
            'items'         => new external_multiple_structure(
                new external_single_structure([
                    'id'       => new external_value(PARAM_INT, ''),
                    'type'     => new external_value(PARAM_ALPHA, ''),
                    // PARAM_RAW porque los items 'label' legítimamente
                    // contienen HTML (<h3>, <b>...). PARAM_TEXT lo rechaza.
                    'name'     => new external_value(PARAM_RAW, 'Puede contener HTML para labels'),
                    'position' => new external_value(PARAM_INT, ''),
                ])
            ),
            'errors'        => new external_multiple_structure(
                new external_single_structure([
                    'idx'   => new external_value(PARAM_INT, ''),
                    'error' => new external_value(PARAM_TEXT, ''),
                ])
            ),
            'feedback_id'   => new external_value(PARAM_INT, ''),
        ]);
    }
}
