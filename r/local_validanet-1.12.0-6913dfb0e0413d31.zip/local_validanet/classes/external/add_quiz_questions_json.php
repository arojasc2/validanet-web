<?php
// Función WS: local_validanet_add_quiz_questions_json
// Reemplazo SIMPLIFICADO de add_quiz_questions_gift. Recibe las preguntas
// como JSON (esquema producido por el Builder IA) y las inserta directamente
// vía qtype->save_question() — sin pasar por el parser GIFT (que tiene
// problemas con HTML en questiontext, escape de :, etc.).
//
// Tipos soportados: multichoice (single), multichoice_multi, short_answer,
// numerical, match (matching).

namespace local_validanet\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;
use core_external\external_multiple_structure;
use context_module;
use stdClass;

class add_quiz_questions_json extends external_api {

    // Hardening v1.10: límites para evitar abuso del WS
    private const MAX_QUESTIONS = 50;
    private const MAX_QUESTIONTEXT_LEN = 20000;
    private const MAX_OPTIONS_PER_Q = 12;

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid'          => new external_value(PARAM_INT, 'course_modules.id del quiz'),
            'questions_json' => new external_value(PARAM_RAW, 'JSON array de preguntas (schema Builder IA)'),
            'category_name' => new external_value(PARAM_TEXT, 'Nombre de la categoría', VALUE_DEFAULT, ''),
        ]);
    }

    public static function execute(int $cmid, string $questions_json,
                                    string $category_name = ''): array {
        global $DB, $CFG, $USER;
        require_once($CFG->libdir . '/questionlib.php');
        require_once($CFG->dirroot . '/mod/quiz/locallib.php');

        $params = self::validate_parameters(self::execute_parameters(), [
            'cmid' => $cmid, 'questions_json' => $questions_json,
            'category_name' => $category_name,
        ]);

        $cm = get_coursemodule_from_id('quiz', $params['cmid'], 0, false, MUST_EXIST);
        $context = context_module::instance($cm->id);
        self::validate_context($context);
        require_capability('mod/quiz:manage', $context);
        require_capability('moodle/question:add', $context);

        $quiz = $DB->get_record('quiz', ['id' => $cm->instance], '*', MUST_EXIST);
        $quiz->cmid = $cm->id;
        $course = get_course($cm->course);

        $questions = json_decode($params['questions_json'], true);
        if (!is_array($questions)) {
            throw new \invalid_parameter_exception('questions_json no es un array JSON válido');
        }
        // Hardening: cap de cantidad y de tamaño por pregunta
        if (count($questions) > self::MAX_QUESTIONS) {
            $questions = array_slice($questions, 0, self::MAX_QUESTIONS);
        }
        foreach ($questions as &$q) {
            if (!is_array($q)) continue;
            if (isset($q['text']) && strlen((string)$q['text']) > self::MAX_QUESTIONTEXT_LEN) {
                $q['text'] = mb_substr((string)$q['text'], 0, self::MAX_QUESTIONTEXT_LEN, 'UTF-8');
            }
            if (isset($q['options']) && is_array($q['options']) && count($q['options']) > self::MAX_OPTIONS_PER_Q) {
                $q['options'] = array_slice($q['options'], 0, self::MAX_OPTIONS_PER_Q);
            }
        }
        unset($q);

        error_log(sprintf('[validanet_audit] user=%d action=add_quiz_questions_json '
            . 'cmid=%d n_questions=%d',
            $USER->id, $cm->id, count($questions)));

        $catname = trim($params['category_name']) ?: ('Evaluación — ' . $cm->name);
        $category = self::get_or_create_category($context, $catname);

        // Distribuir 100 puntos entre todas las preguntas. La 1ra absorbe el
        // remainder para que la suma sea exactamente 100 (Moodle quiz.grade=100).
        $n_valid = 0;
        foreach ($questions as $q) {
            if (is_array($q) && !empty($q['type'])) $n_valid++;
        }
        $base_mark = $n_valid > 0 ? floor(10000.0 / $n_valid) / 100 : 1.0;
        $remainder = $n_valid > 0 ? round(100.0 - ($base_mark * $n_valid), 2) : 0.0;

        $added = [];
        $errors = [];
        $valid_idx = 0;
        foreach ($questions as $idx => $q) {
            try {
                $built = self::build_question_obj($q, $category, $idx);
                if (!$built) {
                    $errors[] = ['idx' => $idx, 'error' => 'No se pudo construir la pregunta'];
                    continue;
                }
                // Asigna la fracción del puntaje total (la 1ra absorbe el remainder)
                $built->defaultmark = $base_mark + ($valid_idx === 0 ? $remainder : 0.0);
                $valid_idx++;
                $qid = self::raw_create_question($built, $context);
                // El mark que mostrará el quiz por pregunta lo gestiona quiz_slots
                quiz_add_quiz_question($qid, $quiz, 0, $built->defaultmark);
                $added[] = [
                    'id' => (int) $qid,
                    'name' => mb_substr((string) $built->name, 0, 200, 'UTF-8'),
                    'qtype' => (string) $built->qtype,
                ];
            } catch (\Throwable $e) {
                error_log('local_validanet add_question failed idx=' . $idx . ': '
                          . $e->getMessage() . ' | ' . $e->getTraceAsString());
                $errors[] = [
                    'idx' => $idx,
                    'name' => mb_substr((string) ($q['title'] ?? '?'), 0, 100, 'UTF-8'),
                    'qtype' => (string) ($q['type'] ?? '?'),
                    'error' => mb_substr((string)$e->getMessage(), 0, 400, 'UTF-8'),
                ];
            }
        }

        quiz_update_sumgrades($quiz);

        return [
            'ok' => count($added) > 0,
            'questions_added' => count($added),
            'questions' => $added,
            'errors' => $errors,
            'category_id' => (int) $category->id,
        ];
    }

    /**
     * Helper: si el valor es array editor ['text' => ...], devuelve text;
     * si es string, lo devuelve tal cual.
     */
    private static function extract_text_value($v): string {
        if (is_array($v)) {
            return (string) ($v['text'] ?? '');
        }
        return (string) $v;
    }

    /**
     * INSERT directo en question_bank_entries + question_versions + question
     * + tablas de opciones específicas del qtype. Bypasses save_question
     * que es versión-aware y daba problemas con questiontext vacío.
     */
    private static function raw_create_question(\stdClass $built, \context $context): int {
        global $DB, $USER;

        $now = time();
        $userid = $USER->id ?: get_admin()->id;

        // 1) question_bank_entries
        $qbe = new \stdClass();
        $qbe->questioncategoryid = $built->category;
        $qbe->idnumber = null;
        $qbe->ownerid = $userid;
        $qbe_id = $DB->insert_record('question_bank_entries', $qbe);

        // 2) question (sin versionar aún, lo insertamos primero)
        $q = new \stdClass();
        $q->parent = 0;
        $q->name = $built->name;
        $q->questiontext = self::extract_text_value($built->questiontext);
        $q->questiontextformat = FORMAT_HTML;
        $q->generalfeedback = self::extract_text_value($built->generalfeedback ?? '');
        $q->generalfeedbackformat = FORMAT_HTML;
        $q->defaultmark = (float) ($built->defaultmark ?? 1.0);
        $q->penalty = (float) ($built->penalty ?? 0);
        $q->qtype = $built->qtype;
        $q->length = 1;
        $q->stamp = make_unique_id_code();
        $q->timecreated = $now;
        $q->timemodified = $now;
        $q->createdby = $userid;
        $q->modifiedby = $userid;
        $q->idnumber = null;
        $q_id = $DB->insert_record('question', $q);

        // 3) question_versions — versión 1 lista
        $qv = new \stdClass();
        $qv->questionbankentryid = $qbe_id;
        $qv->version = 1;
        $qv->questionid = $q_id;
        $qv->status = 'ready';
        $DB->insert_record('question_versions', $qv);

        // 4) Tablas específicas del qtype
        switch ($built->qtype) {
            case 'multichoice':
                self::insert_multichoice_options($q_id, $built);
                break;
            case 'shortanswer':
                self::insert_shortanswer_options($q_id, $built);
                break;
            case 'numerical':
                self::insert_numerical_options($q_id, $built);
                break;
            case 'match':
                self::insert_match_options($q_id, $built);
                break;
        }

        return (int) $q_id;
    }

    /** Inserta question_answers (opciones) + qtype_multichoice_options. */
    private static function insert_multichoice_options(int $qid, \stdClass $b): void {
        global $DB;
        $answer_ids = [];
        $answers = $b->answer ?? [];
        $fractions = $b->fraction ?? [];
        $feedbacks = $b->feedback ?? [];
        foreach ($answers as $i => $atext) {
            $a = new \stdClass();
            $a->question = $qid;
            $a->answer = self::extract_text_value($atext);
            $a->answerformat = FORMAT_HTML;
            $a->fraction = (float) ($fractions[$i] ?? 0);
            $a->feedback = self::extract_text_value($feedbacks[$i] ?? '');
            $a->feedbackformat = FORMAT_HTML;
            $aid = $DB->insert_record('question_answers', $a);
            $answer_ids[] = $aid;
        }
        $opts = new \stdClass();
        $opts->questionid = $qid;
        $opts->layout = 0;
        $opts->single = (int) ($b->single ?? 1);
        $opts->shuffleanswers = (int) ($b->shuffleanswers ?? 1);
        $opts->correctfeedback = '';
        $opts->correctfeedbackformat = FORMAT_HTML;
        $opts->partiallycorrectfeedback = '';
        $opts->partiallycorrectfeedbackformat = FORMAT_HTML;
        $opts->incorrectfeedback = '';
        $opts->incorrectfeedbackformat = FORMAT_HTML;
        $opts->answernumbering = 'abc';
        $opts->shownumcorrect = 0;
        $opts->showstandardinstruction = 0;
        $DB->insert_record('qtype_multichoice_options', $opts);
    }

    private static function insert_shortanswer_options(int $qid, \stdClass $b): void {
        global $DB;
        $answers = $b->answer ?? [];
        $fractions = $b->fraction ?? [];
        foreach ($answers as $i => $ans) {
            $a = new \stdClass();
            $a->question = $qid;
            $a->answer = (string) $ans;
            $a->answerformat = 0;
            $a->fraction = (float) ($fractions[$i] ?? 1.0);
            $a->feedback = '';
            $a->feedbackformat = FORMAT_HTML;
            $DB->insert_record('question_answers', $a);
        }
        $opts = new \stdClass();
        $opts->questionid = $qid;
        $opts->usecase = (int) ($b->usecase ?? 0);
        $DB->insert_record('qtype_shortanswer_options', $opts);
    }

    private static function insert_numerical_options(int $qid, \stdClass $b): void {
        global $DB;
        $answers = $b->answer ?? [];
        $fractions = $b->fraction ?? [];
        $tolerances = $b->tolerance ?? [];
        foreach ($answers as $i => $ans) {
            $a = new \stdClass();
            $a->question = $qid;
            $a->answer = (string) $ans;
            $a->answerformat = 0;
            $a->fraction = (float) ($fractions[$i] ?? 1.0);
            $a->feedback = '';
            $a->feedbackformat = FORMAT_HTML;
            $aid = $DB->insert_record('question_answers', $a);
            // question_numerical = vincula answer con tolerance
            $n = new \stdClass();
            $n->question = $qid;
            $n->answer = $aid;
            $n->tolerance = (float) ($tolerances[$i] ?? 0);
            $DB->insert_record('question_numerical', $n);
        }
        $opts = new \stdClass();
        $opts->questionid = $qid;
        $opts->showunits = 3;
        $opts->unitsleft = 0;
        $opts->unitgradingtype = 0;
        $opts->unitpenalty = 0.1;
        $DB->insert_record('question_numerical_options', $opts);
    }

    private static function insert_match_options(int $qid, \stdClass $b): void {
        global $DB;
        $opts = new \stdClass();
        $opts->questionid = $qid;
        $opts->shuffleanswers = (int) ($b->shuffleanswers ?? 1);
        $opts->correctfeedback = '';
        $opts->correctfeedbackformat = FORMAT_HTML;
        $opts->partiallycorrectfeedback = '';
        $opts->partiallycorrectfeedbackformat = FORMAT_HTML;
        $opts->incorrectfeedback = '';
        $opts->incorrectfeedbackformat = FORMAT_HTML;
        $opts->shownumcorrect = 0;
        $DB->insert_record('qtype_match_options', $opts);
        $subs = $b->subquestions ?? [];
        $sans = $b->subanswers ?? [];
        foreach ($subs as $i => $sq) {
            $s = new \stdClass();
            $s->questionid = $qid;
            $s->questiontext = self::extract_text_value($sq);
            $s->questiontextformat = FORMAT_HTML;
            $s->answertext = (string) ($sans[$i] ?? '');
            $DB->insert_record('qtype_match_subquestions', $s);
        }
    }

    /**
     * Convierte una pregunta del schema Builder IA a stdClass listo para
     * qtype->save_question(). Retorna null si el tipo no se reconoce.
     */
    private static function build_question_obj(array $q, stdClass $category, int $idx): ?stdClass {
        global $USER;

        $obj = new stdClass();
        $obj->category = $category->id;
        $obj->name = mb_substr((string) ($q['title'] ?? ('Pregunta ' . ($idx + 1))), 0, 255);
        // Editor-formato para questiontext (Moodle 4.x espera esto cuando se
        // invoca save_question desde código)
        $qtext_html = self::compose_questiontext($q);
        $obj->questiontext = [
            'text' => $qtext_html,
            'format' => FORMAT_HTML,
            'itemid' => 0,
        ];
        $obj->questiontextformat = FORMAT_HTML;
        $obj->generalfeedback = [
            'text' => (string) ($q['general_feedback'] ?? ''),
            'format' => FORMAT_HTML,
            'itemid' => 0,
        ];
        $obj->generalfeedbackformat = FORMAT_HTML;
        $obj->defaultmark = 1.0;
        $obj->penalty = 0.0;
        $obj->hidden = 0;
        $obj->createdby = $USER->id ?: get_admin()->id;
        $obj->modifiedby = $obj->createdby;
        $obj->idnumber = null;
        $obj->status = 'ready';

        $type = (string) ($q['type'] ?? 'multichoice');

        switch ($type) {
            case 'multichoice':
            case 'multichoice_multi':
                $obj->qtype = 'multichoice';
                return self::build_multichoice($obj, $q, $type === 'multichoice_multi');

            case 'short_answer':
                $obj->qtype = 'shortanswer';
                return self::build_shortanswer($obj, $q);

            case 'numerical':
                $obj->qtype = 'numerical';
                return self::build_numerical($obj, $q);

            case 'matching':
            case 'match':
                $obj->qtype = 'match';
                return self::build_match($obj, $q);
        }
        return null;
    }

    /**
     * Prepende la "caja AE" al questiontext si la pregunta tiene ae_ref.
     * Usa markup minimal (sin atributos style complejos) para sobrevivir el
     * HTML purifier de Moodle.
     */
    private static function compose_questiontext(array $q): string {
        $ae = trim((string) ($q['ae_ref'] ?? ''));
        $text = (string) ($q['text'] ?? '');
        if ($ae !== '') {
            $ae_safe = s($ae);
            $badge = "<p><strong>\u{1F3AF} Evalúa: {$ae_safe}</strong></p>";
            return $badge . $text;
        }
        return $text;
    }

    private static function build_multichoice(stdClass $obj, array $q, bool $multi): stdClass {
        $opts = $q['options'] ?? [];
        if (!is_array($opts) || empty($opts)) {
            $opts = [];
        }
        $obj->single = $multi ? 0 : 1;
        $obj->shuffleanswers = 1;
        $obj->answernumbering = 'abc';
        $obj->showstandardinstruction = 0;
        $obj->correctfeedback = ['text' => '', 'format' => FORMAT_HTML];
        $obj->partiallycorrectfeedback = ['text' => '', 'format' => FORMAT_HTML];
        $obj->incorrectfeedback = ['text' => '', 'format' => FORMAT_HTML];

        $n_correct = 0;
        foreach ($opts as $o) {
            if (!empty($o['correct'])) $n_correct++;
        }
        if ($n_correct === 0) $n_correct = 1;
        $per_correct = $multi ? round(1.0 / $n_correct, 7) : 1.0;
        $per_wrong = $multi ? -1.0 : 0.0;

        $obj->answer = [];
        $obj->fraction = [];
        $obj->feedback = [];
        foreach ($opts as $o) {
            $obj->answer[] = ['text' => (string) ($o['text'] ?? ''), 'format' => FORMAT_HTML];
            $obj->fraction[] = !empty($o['correct']) ? $per_correct : $per_wrong;
            $obj->feedback[] = [
                'text' => (string) ($o['feedback'] ?? ''),
                'format' => FORMAT_HTML,
            ];
        }
        return $obj;
    }

    private static function build_shortanswer(stdClass $obj, array $q): stdClass {
        $accepted = $q['accepted_answers'] ?? [];
        if (!is_array($accepted) || empty($accepted)) {
            $accepted = [(string) ($q['answer'] ?? '')];
        }
        $obj->usecase = 0;
        $obj->answer = [];
        $obj->fraction = [];
        $obj->feedback = [];
        foreach ($accepted as $ans) {
            $a = trim((string) $ans);
            if ($a === '') continue;
            $obj->answer[] = $a;
            $obj->fraction[] = 1.0;
            $obj->feedback[] = ['text' => '', 'format' => FORMAT_HTML];
        }
        return $obj;
    }

    private static function build_numerical(stdClass $obj, array $q): stdClass {
        $ans = $q['answer'] ?? 0;
        $tol = $q['tolerance'] ?? 0;
        $obj->answer = [(string) $ans];
        $obj->fraction = [1.0];
        $obj->tolerance = [(float) $tol];
        $obj->feedback = [['text' => '', 'format' => FORMAT_HTML]];
        $obj->unitrole = 3; // 3 = no units
        $obj->unitpenalty = 0.1;
        $obj->unitgradingtype = 0;
        $obj->unitsleft = 0;
        $obj->multiplier = [1];
        $obj->unit = [''];
        return $obj;
    }

    private static function build_match(stdClass $obj, array $q): stdClass {
        $pairs = $q['pairs'] ?? [];
        if (!is_array($pairs)) $pairs = [];
        $obj->shuffleanswers = 1;
        $obj->correctfeedback = ['text' => '', 'format' => FORMAT_HTML];
        $obj->partiallycorrectfeedback = ['text' => '', 'format' => FORMAT_HTML];
        $obj->incorrectfeedback = ['text' => '', 'format' => FORMAT_HTML];
        $obj->subquestions = [];
        $obj->subanswers = [];
        foreach ($pairs as $p) {
            $left = (string) ($p['left'] ?? '');
            $right = (string) ($p['right'] ?? '');
            if ($left === '' || $right === '') continue;
            $obj->subquestions[] = ['text' => $left, 'format' => FORMAT_HTML];
            $obj->subanswers[] = $right;
        }
        // Match requiere al menos 2 pares para guardar
        while (count($obj->subquestions) < 3) {
            $obj->subquestions[] = ['text' => '', 'format' => FORMAT_HTML];
            $obj->subanswers[] = '';
        }
        return $obj;
    }

    private static function get_or_create_category(\context $context, string $name): stdClass {
        global $DB;
        $cat = $DB->get_record('question_categories',
            ['contextid' => $context->id, 'name' => $name]);
        if ($cat) return $cat;
        $root = $DB->get_record('question_categories',
            ['contextid' => $context->id, 'parent' => 0]);
        if (!$root) {
            $root = new stdClass();
            $root->name = 'top';
            $root->info = '';
            $root->infoformat = FORMAT_HTML;
            $root->contextid = $context->id;
            $root->parent = 0;
            $root->sortorder = 0;
            $root->stamp = make_unique_id_code();
            $root->id = $DB->insert_record('question_categories', $root);
        }
        $cat = new stdClass();
        $cat->name = $name;
        $cat->info = '';
        $cat->infoformat = FORMAT_HTML;
        $cat->contextid = $context->id;
        $cat->parent = $root->id;
        $cat->sortorder = 999;
        $cat->stamp = make_unique_id_code();
        $cat->id = $DB->insert_record('question_categories', $cat);
        return $cat;
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'ok' => new external_value(PARAM_BOOL, ''),
            'questions_added' => new external_value(PARAM_INT, ''),
            'questions' => new external_multiple_structure(
                new external_single_structure([
                    'id' => new external_value(PARAM_INT, ''),
                    'name' => new external_value(PARAM_TEXT, ''),
                    'qtype' => new external_value(PARAM_ALPHANUMEXT, ''),
                ])
            ),
            'errors' => new external_multiple_structure(
                new external_single_structure([
                    'idx' => new external_value(PARAM_INT, ''),
                    'name' => new external_value(PARAM_TEXT, '', VALUE_OPTIONAL),
                    'qtype' => new external_value(PARAM_ALPHANUMEXT, '', VALUE_OPTIONAL),
                    'error' => new external_value(PARAM_TEXT, ''),
                ])
            ),
            'category_id' => new external_value(PARAM_INT, ''),
        ]);
    }
}
