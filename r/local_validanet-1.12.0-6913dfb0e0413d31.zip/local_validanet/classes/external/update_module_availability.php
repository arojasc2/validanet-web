<?php
// Función WS: local_validanet_update_module_availability
// Permite actualizar el campo `availability` de un course_module ya creado.
// Útil para aplicar restricciones cross-módulo después de que todos los
// recursos están deployados (ej. "no desbloquear apuntes del módulo 2 hasta
// aprobar el parcial del módulo 1").
namespace local_validanet\external;

defined('MOODLE_INTERNAL') || die();

use external_api;
use external_function_parameters;
use external_single_structure;
use external_value;
use context_course;

require_once($CFG->libdir . '/externallib.php');

class update_module_availability extends external_api {

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid'              => new external_value(PARAM_INT, 'course module id'),
            'availability_json' => new external_value(PARAM_RAW,
                'JSON Moodle availability (string vacío = sin restricción)',
                VALUE_DEFAULT, ''),
        ]);
    }

    public static function execute(int $cmid, string $availability_json = ''): array {
        global $DB, $USER;

        $params = self::validate_parameters(self::execute_parameters(), [
            'cmid' => $cmid, 'availability_json' => $availability_json,
        ]);

        $cm = get_coursemodule_from_id(null, $params['cmid'], 0, false, MUST_EXIST);
        $context = context_course::instance($cm->course);
        self::validate_context($context);
        require_capability('moodle/course:manageactivities', $context);

        // Validar que sea JSON parseable (o vacío para limpiar)
        $avail = trim($params['availability_json']);
        if ($avail !== '') {
            $decoded = json_decode($avail, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new \invalid_parameter_exception(
                    'availability_json no es JSON válido: ' . json_last_error_msg()
                );
            }
        } else {
            $avail = null;  // null = sin restricción
        }

        $DB->set_field('course_modules', 'availability', $avail, ['id' => $cm->id]);
        rebuild_course_cache($cm->course, true);

        error_log(sprintf(
            '[validanet_audit] user=%d action=update_module_availability '
            . 'cmid=%d course=%d has_restriction=%s',
            $USER->id, $cm->id, $cm->course, $avail ? 'yes' : 'no'
        ));

        return [
            'ok' => true,
            'cmid' => $cm->id,
            'availability' => $avail ?: '',
        ];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'ok'           => new external_value(PARAM_BOOL),
            'cmid'         => new external_value(PARAM_INT),
            'availability' => new external_value(PARAM_RAW),
        ]);
    }
}
