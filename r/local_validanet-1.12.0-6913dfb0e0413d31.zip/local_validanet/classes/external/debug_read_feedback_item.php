<?php
// Función WS de DEBUG: lee la fila cruda de feedback_item para inspeccionar
// presentation, options y otros campos byte-por-byte.

namespace local_validanet\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;

class debug_read_feedback_item extends external_api {

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'feedbackid' => new external_value(PARAM_INT, 'feedback.id (instance)'),
            'limit'      => new external_value(PARAM_INT, 'Max items a retornar', VALUE_DEFAULT, 5),
        ]);
    }

    public static function execute(int $feedbackid, int $limit = 5): array {
        global $DB;

        if (!get_config('local_validanet', 'debug_ws_enabled')) {
            throw new \moodle_exception('accessexception', 'webservice', '', null,
                'debug_read_feedback_item deshabilitada. Activar con set_config.');
        }

        $params = self::validate_parameters(self::execute_parameters(), [
            'feedbackid' => $feedbackid, 'limit' => $limit,
        ]);

        $cm = get_coursemodule_from_instance('feedback', $params['feedbackid'], 0, false, MUST_EXIST);
        $context = \context_module::instance($cm->id);
        self::validate_context($context);
        require_capability('mod/feedback:edititems', $context);

        $rows = $DB->get_records('feedback_item', ['feedback' => $params['feedbackid']],
                                   'position ASC', '*', 0, $params['limit']);
        $out = [];
        foreach ($rows as $r) {
            $out[] = [
                'id' => (int) $r->id,
                'typ' => (string) $r->typ,
                'name' => mb_substr((string) ($r->name ?: ''), 0, 200, 'UTF-8'),
                'label' => (string) ($r->label ?: ''),
                'presentation_len' => strlen((string) $r->presentation),
                'presentation_hex' => bin2hex(substr((string) $r->presentation, 0, 250)),
                'presentation_b64' => base64_encode(substr((string) $r->presentation, 0, 500)),
                'presentation_raw' => mb_substr((string) ($r->presentation ?: ''), 0, 500, 'UTF-8'),
                'options' => mb_substr((string) ($r->options ?: ''), 0, 200, 'UTF-8'),
                'hasvalue' => (int) $r->hasvalue,
                'required' => (int) $r->required,
                'position' => (int) $r->position,
            ];
        }
        return ['ok' => true, 'count' => count($out), 'items' => $out];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'ok' => new external_value(PARAM_BOOL, ''),
            'count' => new external_value(PARAM_INT, ''),
            'items' => new \core_external\external_multiple_structure(
                new external_single_structure([
                    'id' => new external_value(PARAM_INT, ''),
                    'typ' => new external_value(PARAM_ALPHA, ''),
                    'name' => new external_value(PARAM_RAW, ''),
                    'label' => new external_value(PARAM_RAW, ''),
                    'presentation_len' => new external_value(PARAM_INT, ''),
                    'presentation_hex' => new external_value(PARAM_RAW, 'hex de los primeros 250 bytes'),
                    'presentation_b64' => new external_value(PARAM_RAW, 'base64 de los primeros 500 bytes'),
                    'presentation_raw' => new external_value(PARAM_RAW, 'string crudo'),
                    'options' => new external_value(PARAM_RAW, ''),
                    'hasvalue' => new external_value(PARAM_INT, ''),
                    'required' => new external_value(PARAM_INT, ''),
                    'position' => new external_value(PARAM_INT, ''),
                ])
            ),
        ]);
    }
}
