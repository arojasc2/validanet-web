<?php
// Función WS: local_validanet_create_quiz
// Crea un mod_quiz con configuración SENCE-friendly (defaults para diagnóstico,
// formativo, sumativo). Las preguntas se agregan luego con
// local_validanet_add_quiz_questions_gift.

namespace local_validanet\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;
use context_course;
use stdClass;
use invalid_parameter_exception;

class create_quiz extends external_api {

    /** Presets de configuración por finalidad del quiz. */
    private const PRESETS = ['diagnostic', 'formative', 'partial', 'summative'];

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'courseid'    => new external_value(PARAM_INT, 'ID del curso'),
            'section'     => new external_value(PARAM_INT, 'Número de sección (0-based)'),
            'name'        => new external_value(PARAM_TEXT, 'Nombre del quiz'),
            'intro'       => new external_value(PARAM_RAW, 'Descripción/intro HTML', VALUE_DEFAULT, ''),
            'preset'      => new external_value(PARAM_ALPHA, 'Preset: diagnostic|formative|partial|summative', VALUE_DEFAULT, 'formative'),
            'timeopen'    => new external_value(PARAM_INT, 'Unix ts apertura (0=ya)', VALUE_DEFAULT, 0),
            'timeclose'   => new external_value(PARAM_INT, 'Unix ts cierre (0=sin)', VALUE_DEFAULT, 0),
            'timelimit'   => new external_value(PARAM_INT, 'Límite en segundos (0=sin)', VALUE_DEFAULT, 0),
            'attempts'    => new external_value(PARAM_INT, 'Intentos permitidos (0=ilimitado)', VALUE_DEFAULT, 0),
            'grade_passing' => new external_value(PARAM_FLOAT, 'Nota mínima aprobación (0-10)', VALUE_DEFAULT, 6.0),
            'shuffleanswers' => new external_value(PARAM_BOOL, 'Barajar respuestas', VALUE_DEFAULT, true),
            'visible'     => new external_value(PARAM_BOOL, 'Visible', VALUE_DEFAULT, true),
            'completion'  => new external_value(PARAM_INT, '0=ninguna 1=manual 2=automatic', VALUE_DEFAULT, 0),
            'completionview'      => new external_value(PARAM_BOOL, 'Completar al ver', VALUE_DEFAULT, false),
            'completionusegrade'  => new external_value(PARAM_BOOL, 'Completar usando nota', VALUE_DEFAULT, false),
            'completionpassgrade' => new external_value(PARAM_BOOL, 'Requiere nota aprobación', VALUE_DEFAULT, false),
            'availability_json'   => new external_value(PARAM_RAW, 'JSON Moodle availability', VALUE_DEFAULT, ''),
            'overall_feedback_json' => new external_value(PARAM_RAW,
                'JSON array de feedback global por rango de nota. Schema:
[{"min_grade": 0.0, "max_grade": 5.9, "feedback": "<p>HTML...</p>"},
 {"min_grade": 6.0, "max_grade": 7.9, "feedback": "..."},
 {"min_grade": 8.0, "max_grade": 10.0, "feedback": "..."}]
Las notas son sobre la escala del quiz (grade field, default 10).', VALUE_DEFAULT, ''),
        ]);
    }

    public static function execute(int $courseid, int $section, string $name,
                                    string $intro = '', string $preset = 'formative',
                                    int $timeopen = 0, int $timeclose = 0, int $timelimit = 0,
                                    int $attempts = 0, float $grade_passing = 6.0,
                                    bool $shuffleanswers = true, bool $visible = true,
                                    int $completion = 0, bool $completionview = false,
                                    bool $completionusegrade = false, bool $completionpassgrade = false,
                                    string $availability_json = '',
                                    string $overall_feedback_json = ''): array {
        global $DB, $CFG;
        require_once($CFG->dirroot . '/course/lib.php');
        require_once($CFG->dirroot . '/course/modlib.php');
        require_once($CFG->dirroot . '/mod/quiz/lib.php');

        $params = self::validate_parameters(self::execute_parameters(), [
            'courseid' => $courseid, 'section' => $section, 'name' => $name,
            'intro' => $intro, 'preset' => $preset,
            'timeopen' => $timeopen, 'timeclose' => $timeclose, 'timelimit' => $timelimit,
            'attempts' => $attempts, 'grade_passing' => $grade_passing,
            'shuffleanswers' => $shuffleanswers, 'visible' => $visible,
            'completion' => $completion, 'completionview' => $completionview,
            'completionusegrade' => $completionusegrade, 'completionpassgrade' => $completionpassgrade,
            'availability_json' => $availability_json,
            'overall_feedback_json' => $overall_feedback_json,
        ]);
        if (!in_array($params['preset'], self::PRESETS, true)) {
            throw new invalid_parameter_exception('preset inválido. Usar: ' . implode(', ', self::PRESETS));
        }

        $context = context_course::instance($params['courseid']);
        self::validate_context($context);
        require_capability('moodle/course:manageactivities', $context);
        require_capability('mod/quiz:addinstance', $context);

        $course = $DB->get_record('course', ['id' => $params['courseid']], '*', MUST_EXIST);
        $module = $DB->get_record('modules', ['name' => 'quiz'], '*', MUST_EXIST);
        course_create_sections_if_missing($course, [$params['section']]);

        $defaults = self::preset_defaults($params['preset']);

        // Solo campos esenciales — dejamos que Moodle aplique defaults del schema
        // para el resto. La versión anterior fijaba muchos campos que Moodle 4.5
        // ya no requiere y eso generaba dmlwriteexception por tipo.
        $moduleinfo = new stdClass();
        $moduleinfo->course             = $course->id;
        $moduleinfo->module             = $module->id;
        $moduleinfo->modulename         = 'quiz';
        $moduleinfo->section            = $params['section'];
        $moduleinfo->name               = trim($params['name']);
        $moduleinfo->visible            = $params['visible'] ? 1 : 0;
        $moduleinfo->visibleoncoursepage = 1;
        $moduleinfo->intro              = $params['intro'] ?: ' ';
        $moduleinfo->introformat        = FORMAT_HTML;
        $moduleinfo->cmidnumber         = '';
        $moduleinfo->groupmode          = 0;
        $moduleinfo->groupingid         = 0;
        $moduleinfo->showdescription    = empty($params['intro']) ? 0 : 1;

        // Completion (course_modules)
        $moduleinfo->completion         = (int) $params['completion'];
        $moduleinfo->completionview     = $params['completionview'] ? 1 : 0;
        $moduleinfo->completionexpected = 0;
        $moduleinfo->completiongradeitemnumber = null;
        if ($params['completionusegrade']) {
            $moduleinfo->completionusegrade = 1;
            $moduleinfo->completiongradeitemnumber = 0;
        }
        if ($params['completionpassgrade']) {
            $moduleinfo->completionpassgrade = 1;
        }
        if (!empty($params['availability_json'])) {
            $moduleinfo->availability = $params['availability_json'];
        }

        // Quiz-specific essentials
        $moduleinfo->timeopen           = (int) $params['timeopen'];
        $moduleinfo->timeclose          = (int) $params['timeclose'];
        $moduleinfo->timelimit          = (int) $params['timelimit'];
        $moduleinfo->overduehandling    = 'autosubmit';
        $moduleinfo->graceperiod        = 0;
        $moduleinfo->attempts           = (int) $params['attempts'];
        $moduleinfo->grademethod        = (int) $defaults['grademethod'];
        $moduleinfo->grade              = 100.0; // Builder IA: escala 100 puntos siempre
        $moduleinfo->sumgrades          = 0;
        $moduleinfo->decimalpoints      = 2;
        $moduleinfo->questiondecimalpoints = -1;
        $moduleinfo->questionsperpage   = 1;
        $moduleinfo->navmethod          = 'free';
        $moduleinfo->shuffleanswers     = $params['shuffleanswers'] ? 1 : 0;
        $moduleinfo->preferredbehaviour = (string) $defaults['preferredbehaviour'];
        // Campos string NOT NULL en Moodle 4.5 que add_moduleinfo no rellena solo.
        // En 4.5 'password' es el nombre del campo en la tabla quiz (legacy) Y
        // 'quizpassword' es el nombre que usan los access rules + el form.
        // Setamos AMBOS para cubrir todos los caminos.
        $moduleinfo->password           = '';
        $moduleinfo->quizpassword       = '';
        $moduleinfo->subnet             = '';
        $moduleinfo->browsersecurity    = '-';
        // Otros NOT NULL del schema 4.5 que conviene rellenar:
        $moduleinfo->overduehandling    = 'autosubmit';
        $moduleinfo->graceperiod        = 0;
        $moduleinfo->delay1             = 0;
        $moduleinfo->delay2             = 0;
        $moduleinfo->canredoquestions   = 0;
        $moduleinfo->attemptonlast      = 0;
        $moduleinfo->showuserpicture    = 0;
        $moduleinfo->showblocks         = 0;
        $moduleinfo->allowofflineattempts = 0;
        $moduleinfo->completionattemptsexhausted = 0;
        $moduleinfo->completionminattempts = 0;

        // Set gradepass BEFORE add_moduleinfo para que se cree grade_item con la nota
        if ($params['grade_passing'] > 0) {
            $moduleinfo->gradepass = (float) $params['grade_passing'];
        }

        // Review options bit flags
        $review = $defaults['review_flags'];
        $moduleinfo->reviewattempt           = (int) $review['attempt'];
        $moduleinfo->reviewcorrectness       = (int) $review['correctness'];
        $moduleinfo->reviewmarks             = (int) $review['marks'];
        $moduleinfo->reviewmaxmarks          = (int) ($review['maxmarks'] ?? $review['marks'] ?? 0);
        $moduleinfo->reviewspecificfeedback  = (int) $review['specificfeedback'];
        $moduleinfo->reviewgeneralfeedback   = (int) $review['generalfeedback'];
        $moduleinfo->reviewrightanswer       = (int) $review['rightanswer'];
        $moduleinfo->reviewoverallfeedback   = (int) $review['overallfeedback'];

        try {
            $created = add_moduleinfo($moduleinfo, $course);
        } catch (\Throwable $e) {
            // Surfacear el error real del DML (1.8.4+).
            $parts = [];
            $parts[] = get_class($e);
            if (property_exists($e, 'errorcode') && $e->errorcode) {
                $parts[] = 'code=' . $e->errorcode;
            }
            $parts[] = 'msg=' . $e->getMessage();
            if (method_exists($e, 'getDebugInfo')) {
                $di = $e->getDebugInfo();
                if ($di) $parts[] = 'debug=' . $di;
            }
            if (property_exists($e, 'error') && !empty($e->error)) {
                $parts[] = 'sql_error=' . $e->error;
            }
            // Dump de campos sospechosos del $moduleinfo para diagnóstico
            $dump = [];
            foreach (['password','quizpassword','subnet','browsersecurity',
                       'overduehandling','grademethod','navmethod',
                       'preferredbehaviour'] as $f) {
                if (property_exists($moduleinfo, $f)) {
                    $v = $moduleinfo->$f;
                    $dump[] = "$f=" . ($v === null ? 'NULL' : (string)$v);
                }
            }
            $parts[] = 'mi=[' . implode(',', $dump) . ']';
            error_log('local_validanet_create_quiz failed: ' . implode(' | ', $parts));
            throw new \Exception('create_quiz add_moduleinfo failed: '
                . substr(implode(' | ', $parts), 0, 1200));
        }

        // gradepass se setea como parte de $moduleinfo->gradepass arriba.
        // Si add_moduleinfo no lo propaga al grade_item, lo forzamos acá.
        if ($params['grade_passing'] > 0) {
            $gi = $DB->get_record('grade_items', [
                'iteminstance' => $created->instance, 'itemmodule' => 'quiz',
                'courseid' => $course->id, 'itemtype' => 'mod',
            ]);
            if ($gi && (float) $gi->gradepass !== (float) $params['grade_passing']) {
                $gi->gradepass = (float) $params['grade_passing'];
                $DB->update_record('grade_items', $gi);
            }
        }

        // Feedback global por rango de nota
        $feedback_inserted = 0;
        if (!empty($params['overall_feedback_json'])) {
            $ranges = json_decode($params['overall_feedback_json'], true);
            if (is_array($ranges)) {
                $DB->delete_records('quiz_feedback', ['quizid' => $created->instance]);
                foreach ($ranges as $r) {
                    if (!is_array($r) || !isset($r['min_grade']) || !isset($r['max_grade'])) {
                        continue;
                    }
                    $fb = new stdClass();
                    $fb->quizid = $created->instance;
                    $fb->feedbacktext = (string) ($r['feedback'] ?? '');
                    $fb->feedbacktextformat = FORMAT_HTML;
                    $fb->mingrade = (float) $r['min_grade'];
                    $fb->maxgrade = (float) $r['max_grade'];
                    $DB->insert_record('quiz_feedback', $fb);
                    $feedback_inserted++;
                }
            }
        }

        global $USER;
        error_log(sprintf('[validanet_audit] user=%d action=create_quiz '
            . 'course=%d section=%d cmid=%d preset=%s grade_pass=%s',
            $USER->id, $params['courseid'], $params['section'],
            (int) $created->coursemodule, $params['preset'], $params['grade_passing']));

        return [
            'ok'         => true,
            'cmid'       => (int) $created->coursemodule,
            'instanceid' => (int) $created->instance,
            'preset'     => $params['preset'],
            'section'    => (int) $params['section'],
            'feedback_ranges' => $feedback_inserted,
        ];
    }

    private static function preset_defaults(string $preset): array {
        // Para Moodle 4.x, los flags review son constantes en mod_quiz_display_options.
        // Aquí los hardcodeamos como bitmasks comunes:
        // - DURING (1), IMMEDIATELY_AFTER (2), LATER_WHILE_OPEN (4), AFTER_CLOSE (8)
        $all_phases = 1 | 2 | 4 | 8;
        $after_close = 8;
        $immediately_and_later = 2 | 4;
        switch ($preset) {
            case 'diagnostic':
                // Sin calificación, muestra respuestas inmediatamente, comportamiento adaptativo
                return [
                    'grademethod' => 1, // GRADEHIGHEST
                    'preferredbehaviour' => 'immediatefeedback',
                    'review_flags' => [
                        'attempt' => $all_phases, 'correctness' => $all_phases,
                        'marks' => 0, 'maxmarks' => 0,
                        'specificfeedback' => $all_phases, 'generalfeedback' => $all_phases,
                        'rightanswer' => $all_phases, 'overallfeedback' => $all_phases,
                    ],
                ];
            case 'formative':
            case 'partial':
                // Califica pero con feedback inmediato (después del intento)
                return [
                    'grademethod' => 1,
                    'preferredbehaviour' => 'deferredfeedback',
                    'review_flags' => [
                        'attempt' => $immediately_and_later, 'correctness' => $immediately_and_later,
                        'marks' => $immediately_and_later, 'maxmarks' => $immediately_and_later,
                        'specificfeedback' => $immediately_and_later, 'generalfeedback' => $immediately_and_later,
                        'rightanswer' => $after_close, 'overallfeedback' => $immediately_and_later,
                    ],
                ];
            case 'summative':
                // Evaluación final: feedback solo después del cierre
                return [
                    'grademethod' => 1,
                    'preferredbehaviour' => 'deferredfeedback',
                    'review_flags' => [
                        'attempt' => $after_close, 'correctness' => $after_close,
                        'marks' => $after_close, 'maxmarks' => $after_close,
                        'specificfeedback' => $after_close, 'generalfeedback' => $after_close,
                        'rightanswer' => $after_close, 'overallfeedback' => $after_close,
                    ],
                ];
        }
        return [];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'ok'         => new external_value(PARAM_BOOL, 'Éxito'),
            'cmid'       => new external_value(PARAM_INT, 'course_modules.id'),
            'instanceid' => new external_value(PARAM_INT, 'quiz.id'),
            'preset'     => new external_value(PARAM_ALPHA, 'Preset aplicado'),
            'section'    => new external_value(PARAM_INT, 'Número de sección'),
            'feedback_ranges' => new external_value(PARAM_INT, 'Rangos de feedback global insertados'),
        ]);
    }
}
