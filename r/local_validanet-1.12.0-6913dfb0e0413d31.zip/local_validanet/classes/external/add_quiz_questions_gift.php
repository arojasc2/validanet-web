<?php
// Función WS: local_validanet_add_quiz_questions_gift
// Parsea texto en formato GIFT (estándar Moodle de import de preguntas), crea
// las preguntas en el banco del contexto del quiz y las asocia al quiz.

namespace local_validanet\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;
use core_external\external_multiple_structure;
use context_module;
use stdClass;
use moodle_exception;
// NOTA: qformat_gift NO se importa con `use` ni se subclasea aquí porque sus
// archivos fuente no están cargados al parsearse este archivo (require_once
// vive dentro de execute()). Lo instanciamos como \qformat_gift en runtime y
// usamos Reflection para llamar al readquestions() protected.

class add_quiz_questions_gift extends external_api {

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid'       => new external_value(PARAM_INT, 'course_modules.id del quiz'),
            'gift_text'  => new external_value(PARAM_RAW, 'Texto GIFT (puede tener varias preguntas)'),
            'category_name' => new external_value(PARAM_TEXT, 'Nombre de la categoría a usar/crear', VALUE_DEFAULT, ''),
        ]);
    }

    public static function execute(int $cmid, string $gift_text, string $category_name = ''): array {
        global $DB, $CFG, $USER;
        require_once($CFG->libdir . '/questionlib.php');
        require_once($CFG->dirroot . '/question/format.php');  // qformat_default (base)
        require_once($CFG->dirroot . '/question/format/gift/format.php');
        require_once($CFG->dirroot . '/question/engine/bank.php');
        require_once($CFG->dirroot . '/mod/quiz/locallib.php');

        $params = self::validate_parameters(self::execute_parameters(), [
            'cmid' => $cmid, 'gift_text' => $gift_text, 'category_name' => $category_name,
        ]);

        $cm = get_coursemodule_from_id('quiz', $params['cmid'], 0, false, MUST_EXIST);
        $context = context_module::instance($cm->id);
        self::validate_context($context);
        require_capability('mod/quiz:manage', $context);
        require_capability('moodle/question:add', $context);

        $quiz = $DB->get_record('quiz', ['id' => $cm->instance], '*', MUST_EXIST);
        $quiz->cmid = $cm->id;
        $course = get_course($cm->course);

        $catname = trim($params['category_name']) ?: ('Builder IA — ' . $cm->name);
        $category = self::get_or_create_category($context, $catname);

        $qformat = new \qformat_gift();
        $qformat->setCategory($category);
        $qformat->setContexts([$context]);
        $qformat->setCourse($course);
        $qformat->setStoponerror(false);
        $qformat->setMatchgrades('error');
        $qformat->setRealfilename('evaluacion.gift');
        $qformat->setFilename('');

        $lines = preg_split('/\r\n|\n|\r/', $params['gift_text']);
        // readquestions() es protected en Moodle 4.0+ — invocar vía Reflection.
        $reflect = new \ReflectionMethod($qformat, 'readquestions');
        $reflect->setAccessible(true);
        $questions = $reflect->invoke($qformat, $lines);
        if (empty($questions)) {
            throw new moodle_exception('No se pudo parsear ninguna pregunta del GIFT');
        }

        $added = [];
        $errors = [];
        foreach ($questions as $q) {
            if (!isset($q->qtype) || $q->qtype === 'category') {
                continue;
            }
            $q->category = $category->id;
            $q->stamp = make_unique_id_code();
            $q->version = make_unique_id_code();
            $q->createdby = $USER->id ?: get_admin()->id;
            $q->modifiedby = $q->createdby;
            $q->timecreated = time();
            $q->timemodified = time();

            try {
                // Path moderno (Moodle 4.x): get_qtype + save_question
                $qtype = \question_bank::get_qtype($q->qtype);
                $newq = $qtype->save_question($q, $q);
                if (!$newq || empty($newq->id)) {
                    throw new moodle_exception("save_question retornó vacío para qtype={$q->qtype}");
                }
                quiz_add_quiz_question((int) $newq->id, $quiz, 0, null);
                $added[] = [
                    'id'    => (int) $newq->id,
                    'name'  => mb_substr((string) ($newq->name ?? ''), 0, 200, 'UTF-8'),
                    'qtype' => (string) $newq->qtype,
                ];
            } catch (\Throwable $e) {
                $errors[] = [
                    'name'  => mb_substr((string) ($q->name ?? '?'), 0, 100, 'UTF-8'),
                    'qtype' => (string) ($q->qtype ?? '?'),
                    'error' => mb_substr((string)$e->getMessage(), 0, 300, 'UTF-8'),
                ];
            }
        }

        // Recalcular sumgrades del quiz
        quiz_update_sumgrades($quiz);

        return [
            'ok'              => count($added) > 0,
            'questions_added' => count($added),
            'questions'       => $added,
            'errors'          => $errors,
            'category_id'     => (int) $category->id,
        ];
    }

    private static function get_or_create_category(\context $context, string $name): stdClass {
        global $DB, $USER;
        $cat = $DB->get_record('question_categories',
            ['contextid' => $context->id, 'name' => $name]);
        if ($cat) {
            return $cat;
        }
        // Buscar root category de este contexto; si no existe, crearla
        $root = $DB->get_record('question_categories',
            ['contextid' => $context->id, 'parent' => 0]);
        if (!$root) {
            $root = new stdClass();
            $root->name = 'top';
            $root->info = '';
            $root->infoformat = FORMAT_HTML;
            $root->contextid = $context->id;
            $root->parent = 0;
            $root->sortorder = 0;
            $root->stamp = make_unique_id_code();
            $root->id = $DB->insert_record('question_categories', $root);
        }
        $cat = new stdClass();
        $cat->name = $name;
        $cat->info = 'Categoría generada por el Builder IA de ValidaNet.';
        $cat->infoformat = FORMAT_HTML;
        $cat->contextid = $context->id;
        $cat->parent = $root->id;
        $cat->sortorder = 999;
        $cat->stamp = make_unique_id_code();
        $cat->id = $DB->insert_record('question_categories', $cat);
        return $cat;
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'ok'              => new external_value(PARAM_BOOL, 'Al menos 1 pregunta agregada'),
            'questions_added' => new external_value(PARAM_INT, 'Cantidad agregada al quiz'),
            'questions'       => new external_multiple_structure(
                new external_single_structure([
                    'id'    => new external_value(PARAM_INT, 'question.id'),
                    'name'  => new external_value(PARAM_TEXT, 'Título corto'),
                    'qtype' => new external_value(PARAM_ALPHANUMEXT, 'Tipo (multichoice, truefalse, ...)'),
                ])
            ),
            'errors'          => new external_multiple_structure(
                new external_single_structure([
                    'name'  => new external_value(PARAM_TEXT, ''),
                    'qtype' => new external_value(PARAM_ALPHANUMEXT, ''),
                    'error' => new external_value(PARAM_TEXT, ''),
                ])
            ),
            'category_id'     => new external_value(PARAM_INT, 'question_categories.id usado'),
        ]);
    }
}
