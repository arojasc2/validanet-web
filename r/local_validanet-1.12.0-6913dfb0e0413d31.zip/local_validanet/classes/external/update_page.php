<?php
// Función WS: local_validanet_update_page
// Actualiza el contenido HTML de una mod_page existente. Útil para iterar el
// contenido generado por IA sin recrear el curso.

namespace local_validanet\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;
use context_module;
use moodle_exception;

class update_page extends external_api {

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid'          => new external_value(PARAM_INT, 'course_modules.id de la página'),
            'name'          => new external_value(PARAM_TEXT, 'Nuevo nombre', VALUE_DEFAULT, null),
            'content'       => new external_value(PARAM_RAW, 'Nuevo contenido HTML', VALUE_DEFAULT, null),
            'contentformat' => new external_value(PARAM_INT, 'FORMAT_HTML=1', VALUE_DEFAULT, FORMAT_HTML),
            'visible'       => new external_value(PARAM_BOOL, 'Visibilidad', VALUE_DEFAULT, null),
            'completion'    => new external_value(PARAM_INT, '0=ninguna 1=manual 2=auto (null=sin tocar)', VALUE_DEFAULT, -1),
            'completionview' => new external_value(PARAM_BOOL, 'Completar al ver', VALUE_DEFAULT, null),
            'availability_json' => new external_value(PARAM_RAW, 'JSON availability (vacío = sin cambio; "null" = limpiar)', VALUE_DEFAULT, ''),
        ]);
    }

    public static function execute(int $cmid, ?string $name = null, ?string $content = null,
                                    int $contentformat = FORMAT_HTML, ?bool $visible = null,
                                    int $completion = -1, ?bool $completionview = null,
                                    string $availability_json = ''): array {
        global $DB, $CFG;
        require_once($CFG->dirroot . '/course/lib.php');
        require_once($CFG->dirroot . '/course/modlib.php');

        $params = self::validate_parameters(self::execute_parameters(), [
            'cmid' => $cmid, 'name' => $name, 'content' => $content,
            'contentformat' => $contentformat, 'visible' => $visible,
            'completion' => $completion, 'completionview' => $completionview,
            'availability_json' => $availability_json,
        ]);

        $cm = get_coursemodule_from_id('page', $params['cmid'], 0, false, MUST_EXIST);
        $context = context_module::instance($cm->id);
        self::validate_context($context);
        require_capability('moodle/course:manageactivities', $context);

        $page = $DB->get_record('page', ['id' => $cm->instance], '*', MUST_EXIST);

        if ($params['content'] !== null) {
            $page->content = $params['content'];
            $page->contentformat = $params['contentformat'];
            $page->revision = ((int) $page->revision) + 1;
        }
        if ($params['name'] !== null) {
            $page->name = trim($params['name']);
        }
        $page->timemodified = time();
        $DB->update_record('page', $page);

        if ($params['name'] !== null) {
            $cm->name = $page->name;
            $DB->update_record('course_modules', $cm);
        }
        if ($params['visible'] !== null) {
            set_coursemodule_visible($cm->id, $params['visible'] ? 1 : 0);
        }

        // Actualizar completion + availability directamente en course_modules
        $cm_dirty = false;
        if ($params['completion'] >= 0) {
            $cm->completion = (int) $params['completion'];
            $cm_dirty = true;
        }
        if ($params['completionview'] !== null) {
            $cm->completionview = $params['completionview'] ? 1 : 0;
            $cm_dirty = true;
        }
        if ($params['availability_json'] === 'null') {
            $cm->availability = null;
            $cm_dirty = true;
        } elseif (!empty($params['availability_json'])) {
            $cm->availability = $params['availability_json'];
            $cm_dirty = true;
        }
        if ($cm_dirty) {
            $DB->update_record('course_modules', $cm);
        }

        rebuild_course_cache($cm->course, true);

        global $USER;
        error_log(sprintf('[validanet_audit] user=%d action=update_page cmid=%d revision=%d',
            $USER->id, (int)$cm->id, (int)$page->revision));

        return [
            'ok'         => true,
            'cmid'       => (int) $cm->id,
            'instanceid' => (int) $page->id,
            'revision'   => (int) $page->revision,
        ];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'ok'         => new external_value(PARAM_BOOL, 'Éxito'),
            'cmid'       => new external_value(PARAM_INT, 'course_modules.id'),
            'instanceid' => new external_value(PARAM_INT, 'page.id'),
            'revision'   => new external_value(PARAM_INT, 'Nueva revisión'),
        ]);
    }
}
