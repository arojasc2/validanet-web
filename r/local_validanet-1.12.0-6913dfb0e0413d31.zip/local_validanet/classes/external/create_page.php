<?php
// Función WS: local_validanet_create_page
// Crea una actividad mod_page en una sección del curso. Moodle core no expone
// creación de módulos vía WS — esta función envuelve add_moduleinfo().

namespace local_validanet\external;

defined('MOODLE_INTERNAL') || die();

// Moodle 4.2+ usa \core_external\*. En 4.0-4.1 estas clases vivían en el
// namespace global (external_api). El plugin requiere ≥ 4.2 (2023042400).
use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;
use context_course;
use stdClass;

class create_page extends external_api {

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'courseid'      => new external_value(PARAM_INT, 'ID del curso'),
            'section'       => new external_value(PARAM_INT, 'Número de sección (0-based)'),
            'name'          => new external_value(PARAM_TEXT, 'Nombre de la página'),
            'content'       => new external_value(PARAM_RAW, 'Contenido HTML de la página'),
            'contentformat' => new external_value(PARAM_INT, 'Formato (FORMAT_HTML=1)', VALUE_DEFAULT, FORMAT_HTML),
            'intro'         => new external_value(PARAM_RAW, 'Intro/descripción', VALUE_DEFAULT, ''),
            'printheading'  => new external_value(PARAM_BOOL, 'Mostrar título', VALUE_DEFAULT, true),
            'printintro'    => new external_value(PARAM_BOOL, 'Mostrar intro', VALUE_DEFAULT, false),
            'visible'       => new external_value(PARAM_BOOL, 'Visible', VALUE_DEFAULT, true),
            'completion'          => new external_value(PARAM_INT, '0=ninguna 1=manual 2=automatic', VALUE_DEFAULT, 0),
            'completionview'      => new external_value(PARAM_BOOL, 'Completar al ver', VALUE_DEFAULT, false),
            'availability_json'   => new external_value(PARAM_RAW, 'JSON Moodle availability (vacío = sin restricción)', VALUE_DEFAULT, ''),
        ]);
    }

    public static function execute(int $courseid, int $section, string $name,
                                    string $content, int $contentformat = FORMAT_HTML,
                                    string $intro = '', bool $printheading = true,
                                    bool $printintro = false, bool $visible = true,
                                    int $completion = 0, bool $completionview = false,
                                    string $availability_json = ''): array {
        global $DB, $CFG;
        require_once($CFG->dirroot . '/course/lib.php');
        require_once($CFG->dirroot . '/course/modlib.php');
        require_once($CFG->libdir . '/resourcelib.php');

        $params = self::validate_parameters(self::execute_parameters(), [
            'courseid'      => $courseid,
            'section'       => $section,
            'name'          => $name,
            'content'       => $content,
            'contentformat' => $contentformat,
            'intro'         => $intro,
            'printheading'  => $printheading,
            'printintro'    => $printintro,
            'visible'       => $visible,
            'completion'    => $completion,
            'completionview' => $completionview,
            'availability_json' => $availability_json,
        ]);

        $context = context_course::instance($params['courseid']);
        self::validate_context($context);
        require_capability('moodle/course:manageactivities', $context);
        require_capability('mod/page:addinstance', $context);

        $course = get_course($params['courseid']);
        $module = $DB->get_record('modules', ['name' => 'page'], '*', MUST_EXIST);

        // Asegura que la sección existe (course_create_sections_if_missing
        // es idempotente).
        course_create_sections_if_missing($course, [$params['section']]);

        $moduleinfo = new stdClass();
        $moduleinfo->course             = $course->id;
        $moduleinfo->module             = $module->id;
        $moduleinfo->modulename         = 'page';
        $moduleinfo->section            = $params['section'];
        $moduleinfo->name               = trim($params['name']);
        $moduleinfo->visible            = $params['visible'] ? 1 : 0;
        $moduleinfo->visibleoncoursepage = 1;
        $moduleinfo->intro              = $params['intro'];
        $moduleinfo->introformat        = FORMAT_HTML;
        $moduleinfo->content            = $params['content'];
        $moduleinfo->contentformat      = $params['contentformat'];
        $moduleinfo->display            = RESOURCELIB_DISPLAY_AUTO;
        $moduleinfo->printheading       = $params['printheading'] ? 1 : 0;
        $moduleinfo->printintro         = $params['printintro'] ? 1 : 0;
        $moduleinfo->printlastmodified  = 1;
        $moduleinfo->revision           = 1;
        $moduleinfo->showdescription    = 0;
        $moduleinfo->cmidnumber         = '';
        $moduleinfo->groupmode          = 0;
        $moduleinfo->groupingid         = 0;
        $moduleinfo->completion         = (int) $params['completion'];
        if ($params['completionview']) {
            $moduleinfo->completionview = 1;
        }
        if (!empty($params['availability_json'])) {
            $moduleinfo->availability = $params['availability_json'];
        }

        $created = add_moduleinfo($moduleinfo, $course);

        global $USER;
        error_log(sprintf('[validanet_audit] user=%d action=create_page '
            . 'course=%d section=%d cmid=%d content_len=%d',
            $USER->id, $params['courseid'], $params['section'],
            (int) $created->coursemodule, strlen($params['content'])));

        return [
            'ok'         => true,
            'cmid'       => (int) $created->coursemodule,
            'instanceid' => (int) $created->instance,
            'section'    => (int) $params['section'],
        ];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'ok'         => new external_value(PARAM_BOOL, 'Éxito'),
            'cmid'       => new external_value(PARAM_INT, 'course_modules.id de la actividad creada'),
            'instanceid' => new external_value(PARAM_INT, 'page.id (instancia)'),
            'section'    => new external_value(PARAM_INT, 'Número de sección'),
        ]);
    }
}
