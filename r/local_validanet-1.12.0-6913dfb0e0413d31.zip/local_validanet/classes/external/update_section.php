<?php
// Función WS: local_validanet_update_section
// Renombra y/o setea el summary de una sección de curso. Moodle core no
// expone esto vía WS — solo edit_section (hide/show/move/delete) y el
// in-place editor del nombre. Esta función cubre el caso completo.

namespace local_validanet\external;

defined('MOODLE_INTERNAL') || die();

// Moodle 4.2+ usa \core_external\*. En 4.0-4.1 estas clases vivían en el
// namespace global (external_api). El plugin requiere ≥ 4.2 (2023042400).
use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;
use context_course;

class update_section extends external_api {

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'courseid'      => new external_value(PARAM_INT, 'ID del curso'),
            'section'       => new external_value(PARAM_INT, 'Número de sección (0-based)'),
            'name'          => new external_value(PARAM_TEXT, 'Nuevo nombre', VALUE_DEFAULT, null),
            'summary'       => new external_value(PARAM_RAW, 'Resumen HTML', VALUE_DEFAULT, null),
            'summaryformat' => new external_value(PARAM_INT, 'Formato del summary (FORMAT_HTML=1)', VALUE_DEFAULT, FORMAT_HTML),
            'visible'       => new external_value(PARAM_BOOL, 'Visibilidad', VALUE_DEFAULT, null),
        ]);
    }

    public static function execute(int $courseid, int $section, ?string $name = null,
                                    ?string $summary = null, int $summaryformat = FORMAT_HTML,
                                    ?bool $visible = null): array {
        global $DB, $CFG;
        require_once($CFG->dirroot . '/course/lib.php');

        $params = self::validate_parameters(self::execute_parameters(), [
            'courseid'      => $courseid,
            'section'       => $section,
            'name'          => $name,
            'summary'       => $summary,
            'summaryformat' => $summaryformat,
            'visible'       => $visible,
        ]);

        $context = context_course::instance($params['courseid']);
        self::validate_context($context);
        require_capability('moodle/course:update', $context);

        $sectionrec = $DB->get_record('course_sections',
            ['course' => $params['courseid'], 'section' => $params['section']],
            '*', MUST_EXIST);

        $data = [];
        if ($params['name'] !== null) {
            $data['name'] = trim($params['name']);
        }
        if ($params['summary'] !== null) {
            $data['summary']       = $params['summary'];
            $data['summaryformat'] = $params['summaryformat'];
        }
        if ($params['visible'] !== null) {
            $data['visible'] = $params['visible'] ? 1 : 0;
        }

        if (!empty($data)) {
            $course = get_course($params['courseid']);
            course_update_section($course, $sectionrec, $data);
        }

        global $USER;
        error_log(sprintf('[validanet_audit] user=%d action=update_section course=%d section=%d fields=%s',
            $USER->id, $params['courseid'], $params['section'], implode(',', array_keys($data))));

        return [
            'ok'         => true,
            'section_id' => (int) $sectionrec->id,
            'section'    => (int) $sectionrec->section,
        ];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'ok'         => new external_value(PARAM_BOOL, 'Éxito'),
            'section_id' => new external_value(PARAM_INT, 'ID de la fila course_sections'),
            'section'    => new external_value(PARAM_INT, 'Número de sección'),
        ]);
    }
}
