<?php
// Función WS: local_validanet_delete_modules
// Envuelve course_delete_module() para borrar una o más activities por cmid.
// Útil para limpiar evaluaciones/recursos viejos antes de un redeploy.

namespace local_validanet\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;
use core_external\external_multiple_structure;
use context_course;

class delete_modules extends external_api {

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmids' => new external_multiple_structure(
                new external_value(PARAM_INT, 'course_modules.id'),
                'Lista de cmids a borrar'
            ),
            'async' => new external_value(PARAM_BOOL, 'Borrar async (deferred)', VALUE_DEFAULT, false),
        ]);
    }

    public static function execute(array $cmids, bool $async = false): array {
        global $DB, $CFG;
        require_once($CFG->dirroot . '/course/lib.php');

        $params = self::validate_parameters(self::execute_parameters(), [
            'cmids' => $cmids, 'async' => $async,
        ]);

        $deleted = [];
        $errors = [];
        foreach ($params['cmids'] as $cmid) {
            try {
                $cm = $DB->get_record('course_modules', ['id' => $cmid]);
                if (!$cm) {
                    $errors[] = ['cmid' => $cmid, 'error' => 'cm no existe'];
                    continue;
                }
                $context = context_course::instance($cm->course);
                self::validate_context($context);
                require_capability('moodle/course:manageactivities', $context);
                course_delete_module($cmid, $params['async']);
                $deleted[] = (int) $cmid;
                global $USER;
                error_log(sprintf('[validanet_audit] user=%d action=delete_module cmid=%d course=%d',
                    $USER->id, (int)$cmid, (int)$cm->course));
            } catch (\Throwable $e) {
                $errors[] = [
                    'cmid' => (int) $cmid,
                    'error' => mb_substr((string)$e->getMessage(), 0, 300, 'UTF-8'),
                ];
            }
        }

        return [
            'ok' => count($deleted) > 0 || empty($params['cmids']),
            'deleted_count' => count($deleted),
            'deleted' => $deleted,
            'errors' => $errors,
        ];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'ok' => new external_value(PARAM_BOOL, ''),
            'deleted_count' => new external_value(PARAM_INT, ''),
            'deleted' => new external_multiple_structure(new external_value(PARAM_INT, '')),
            'errors' => new external_multiple_structure(
                new external_single_structure([
                    'cmid' => new external_value(PARAM_INT, ''),
                    'error' => new external_value(PARAM_TEXT, ''),
                ])
            ),
        ]);
    }
}
