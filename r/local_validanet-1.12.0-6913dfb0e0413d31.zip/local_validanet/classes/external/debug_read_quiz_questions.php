<?php
// Función WS de DEBUG: lee directamente las preguntas de un mod_quiz para
// inspeccionar qué guardó Moodle tras un GIFT import. Solo para diagnóstico.

namespace local_validanet\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;
use core_external\external_multiple_structure;
use context_module;

class debug_read_quiz_questions extends external_api {

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'cmid' => new external_value(PARAM_INT, 'course_modules.id del quiz'),
        ]);
    }

    public static function execute(int $cmid): array {
        global $DB;

        // Hardening v1.10: la WS de debug expone respuestas correctas + feedback
        // de quizzes. SOLO activable explícitamente vía
        // `set_config('debug_ws_enabled', 1, 'local_validanet')`. Por defecto
        // está desactivada en producción.
        if (!get_config('local_validanet', 'debug_ws_enabled')) {
            throw new \moodle_exception('accessexception', 'webservice', '',
                null, 'debug_read_quiz_questions deshabilitada. Activar con '
                    . 'set_config(\'debug_ws_enabled\', 1, \'local_validanet\').');
        }

        $params = self::validate_parameters(self::execute_parameters(), ['cmid' => $cmid]);
        $cm = get_coursemodule_from_id('quiz', $params['cmid'], 0, false, MUST_EXIST);
        $context = context_module::instance($cm->id);
        self::validate_context($context);
        require_capability('mod/quiz:manage', $context);

        // Moodle 4.x: quiz_slots → question_references → question_bank_entries → question
        $sql = "SELECT q.id, q.name, q.questiontext, q.questiontextformat, q.qtype,
                       q.defaultmark, q.generalfeedback, qs.slot
                FROM {quiz_slots} qs
                JOIN {question_references} qr ON qr.itemid = qs.id
                     AND qr.component = 'mod_quiz'
                     AND qr.questionarea = 'slot'
                JOIN {question_bank_entries} qbe ON qbe.id = qr.questionbankentryid
                JOIN {question_versions} qv ON qv.questionbankentryid = qbe.id
                JOIN {question} q ON q.id = qv.questionid
                WHERE qs.quizid = ?
                ORDER BY qs.slot";
        $rows = $DB->get_records_sql($sql, [$cm->instance]);

        $out = [];
        foreach ($rows as $r) {
            $out[] = [
                'question_id' => (int) $r->id,
                'slot' => (int) $r->slot,
                'name' => (string) ($r->name ?: ''),
                'qtype' => (string) ($r->qtype ?: ''),
                'questiontext' => (string) ($r->questiontext ?: ''),
                'questiontextformat' => (int) $r->questiontextformat,
                'qtext_len' => strlen((string) $r->questiontext),
                'generalfeedback' => mb_substr((string) ($r->generalfeedback ?: ''), 0, 300, 'UTF-8'),
            ];
        }

        return [
            'ok' => true,
            'cmid' => (int) $cm->id,
            'quizid' => (int) $cm->instance,
            'count' => count($out),
            'questions' => $out,
        ];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'ok' => new external_value(PARAM_BOOL, ''),
            'cmid' => new external_value(PARAM_INT, ''),
            'quizid' => new external_value(PARAM_INT, ''),
            'count' => new external_value(PARAM_INT, ''),
            'questions' => new external_multiple_structure(
                new external_single_structure([
                    'question_id' => new external_value(PARAM_INT, ''),
                    'slot' => new external_value(PARAM_INT, ''),
                    'name' => new external_value(PARAM_TEXT, ''),
                    'qtype' => new external_value(PARAM_ALPHANUMEXT, ''),
                    'questiontext' => new external_value(PARAM_RAW, ''),
                    'questiontextformat' => new external_value(PARAM_INT, ''),
                    'qtext_len' => new external_value(PARAM_INT, ''),
                    'generalfeedback' => new external_value(PARAM_RAW, ''),
                ])
            ),
        ]);
    }
}
