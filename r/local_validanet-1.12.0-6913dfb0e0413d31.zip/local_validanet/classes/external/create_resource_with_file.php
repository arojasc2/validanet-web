<?php
// Función WS: local_validanet_create_resource_with_file
// Sube un archivo (base64) al área de borradores del usuario WS y crea una
// mod_resource en la sección indicada del curso, todo en una sola llamada.
// Útil para insertar rúbricas PDF generadas por el Builder IA antes de un quiz.

namespace local_validanet\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;
use context_course;
use context_user;
use stdClass;
use invalid_parameter_exception;

class create_resource_with_file extends external_api {

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'courseid'    => new external_value(PARAM_INT, 'ID del curso'),
            'section'     => new external_value(PARAM_INT, 'Número de sección (0-based)'),
            'name'        => new external_value(PARAM_TEXT, 'Nombre del recurso'),
            'intro'       => new external_value(PARAM_RAW, 'Descripción HTML', VALUE_DEFAULT, ''),
            'filename'    => new external_value(PARAM_FILE, 'Nombre del archivo (e.g. rubrica.pdf)'),
            'content_b64' => new external_value(PARAM_RAW, 'Contenido del archivo en base64'),
            'mimetype'    => new external_value(PARAM_TEXT, 'MIME type', VALUE_DEFAULT, 'application/pdf'),
            'visible'     => new external_value(PARAM_BOOL, 'Visible', VALUE_DEFAULT, true),
            'completion'  => new external_value(PARAM_INT, '0=ninguna 1=manual 2=auto', VALUE_DEFAULT, 0),
            'completionview' => new external_value(PARAM_BOOL, 'Completar al ver', VALUE_DEFAULT, false),
            'availability_json' => new external_value(PARAM_RAW, 'JSON Moodle availability', VALUE_DEFAULT, ''),
        ]);
    }

    // Hardening v1.10: limites estrictos + allowlist
    private const ALLOWED_EXTENSIONS = [
        'pdf','docx','doc','xlsx','pptx','png','jpg','jpeg','gif','svg','webp',
        'mp4','mp3','webm','ogg','txt','rtf','odt','ods','odp',
    ];
    private const MAX_DECODED_BYTES = 10 * 1024 * 1024; // 10 MB tras base64-decode

    public static function execute(int $courseid, int $section, string $name,
                                    string $intro = '', string $filename = '',
                                    string $content_b64 = '',
                                    string $mimetype = 'application/pdf',
                                    bool $visible = true,
                                    int $completion = 0, bool $completionview = false,
                                    string $availability_json = ''): array {
        global $DB, $CFG, $USER;
        require_once($CFG->dirroot . '/course/lib.php');
        require_once($CFG->dirroot . '/course/modlib.php');
        require_once($CFG->libdir . '/resourcelib.php');
        require_once($CFG->libdir . '/filelib.php');

        $params = self::validate_parameters(self::execute_parameters(), [
            'courseid' => $courseid, 'section' => $section, 'name' => $name,
            'intro' => $intro, 'filename' => $filename, 'content_b64' => $content_b64,
            'mimetype' => $mimetype, 'visible' => $visible,
            'completion' => $completion, 'completionview' => $completionview,
            'availability_json' => $availability_json,
        ]);

        if (empty($params['filename']) || empty($params['content_b64'])) {
            throw new invalid_parameter_exception('filename y content_b64 son requeridos');
        }

        // Hardening: validar filename (sin path traversal, sin caracteres raros)
        $clean_name = basename($params['filename']);
        if ($clean_name === '' || $clean_name === '.' || $clean_name === '..'
            || strpbrk($clean_name, "\0\r\n/\\") !== false) {
            throw new invalid_parameter_exception('filename inválido (no permitido path traversal ni caracteres especiales)');
        }
        $params['filename'] = $clean_name;

        // Hardening: validar extensión contra allowlist
        $ext = strtolower(pathinfo($clean_name, PATHINFO_EXTENSION));
        if (!$ext || !in_array($ext, self::ALLOWED_EXTENSIONS, true)) {
            throw new invalid_parameter_exception(
                'Extensión no permitida. Usar una de: ' . implode(', ', self::ALLOWED_EXTENSIONS));
        }

        $context = context_course::instance($params['courseid']);
        self::validate_context($context);
        require_capability('moodle/course:manageactivities', $context);

        // 1) Decodificar contenido y subir al área de borradores del WS user
        $content = base64_decode($params['content_b64'], true);
        if ($content === false) {
            throw new invalid_parameter_exception('content_b64 no es base64 válido');
        }
        // Hardening: cap de tamaño tras decode
        if (strlen($content) > self::MAX_DECODED_BYTES) {
            throw new invalid_parameter_exception(
                'Archivo > ' . (self::MAX_DECODED_BYTES / (1024*1024)) . ' MB tras decodificar');
        }
        // Audit log
        error_log(sprintf('[validanet_audit] user=%d action=create_resource_with_file '
            . 'course=%d section=%d filename=%s size=%d ext=%s',
            $USER->id, $params['courseid'], $params['section'],
            $params['filename'], strlen($content), $ext));
        $usercontext = context_user::instance($USER->id);
        $draftitemid = file_get_unused_draft_itemid();
        $fs = get_file_storage();
        $filerec = (object) [
            'contextid' => $usercontext->id,
            'component' => 'user',
            'filearea'  => 'draft',
            'itemid'    => $draftitemid,
            'filepath'  => '/',
            'filename'  => $params['filename'],
            'timecreated'  => time(),
            'timemodified' => time(),
            'mimetype'  => $params['mimetype'] ?: 'application/octet-stream',
            'userid'    => $USER->id,
        ];
        $fs->create_file_from_string($filerec, $content);

        // 2) Crear mod_resource referenciando el draft
        $course = get_course($params['courseid']);
        $module = $DB->get_record('modules', ['name' => 'resource'], '*', MUST_EXIST);
        course_create_sections_if_missing($course, [$params['section']]);

        $moduleinfo = new stdClass();
        $moduleinfo->course             = $course->id;
        $moduleinfo->module             = $module->id;
        $moduleinfo->modulename         = 'resource';
        $moduleinfo->section            = $params['section'];
        $moduleinfo->name               = trim($params['name']);
        $moduleinfo->visible            = $params['visible'] ? 1 : 0;
        $moduleinfo->visibleoncoursepage = 1;
        $moduleinfo->intro              = $params['intro'];
        $moduleinfo->introformat        = FORMAT_HTML;
        $moduleinfo->cmidnumber         = '';
        $moduleinfo->groupmode          = 0;
        $moduleinfo->groupingid         = 0;
        $moduleinfo->completion         = (int) $params['completion'];
        if ($params['completionview']) {
            $moduleinfo->completionview = 1;
        }
        if (!empty($params['availability_json'])) {
            $moduleinfo->availability = $params['availability_json'];
        }
        $moduleinfo->showdescription    = empty($params['intro']) ? 0 : 1;
        $moduleinfo->display            = RESOURCELIB_DISPLAY_AUTO;
        $moduleinfo->printintro         = 0;
        $moduleinfo->printheader        = 1;
        $moduleinfo->printheading       = 1;
        $moduleinfo->showsize           = 1;
        $moduleinfo->showtype           = 1;
        $moduleinfo->showdate           = 0;
        $moduleinfo->files              = $draftitemid;

        $created = add_moduleinfo($moduleinfo, $course);

        return [
            'ok'         => true,
            'cmid'       => (int) $created->coursemodule,
            'instanceid' => (int) $created->instance,
            'section'    => (int) $params['section'],
            'filename'   => $params['filename'],
        ];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'ok'         => new external_value(PARAM_BOOL, 'Éxito'),
            'cmid'       => new external_value(PARAM_INT, 'course_modules.id'),
            'instanceid' => new external_value(PARAM_INT, 'resource.id'),
            'section'    => new external_value(PARAM_INT, 'Sección'),
            'filename'   => new external_value(PARAM_FILE, 'Nombre del archivo subido'),
        ]);
    }
}
