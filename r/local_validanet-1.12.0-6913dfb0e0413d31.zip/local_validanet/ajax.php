<?php
define('AJAX_SCRIPT', true);
require_once(__DIR__ . '/../../config.php');
require_login();
require_capability('moodle/site:config', context_system::instance());

$action = required_param('action', PARAM_ALPHANUMEXT);
header('Content-Type: application/json');

switch ($action) {

    case 'enable_webservices':
        set_config('enablewebservices', 1);
        set_config('enablerestprotocol', 1);
        set_config('extendedusernamechars', 1);
        echo json_encode(['ok' => true]);
        break;

    case 'create_service':
        $admin       = get_admin();
        $servicename = 'validanet_api';
        $service     = $DB->get_record('external_services', ['shortname' => $servicename]);
        if (!$service) {
            $service                  = new stdClass();
            $service->name            = 'ValidaNet API';
            $service->shortname       = $servicename;
            $service->enabled         = 1;
            $service->restrictedusers = 0;
            $service->downloadfiles   = 1;
            $service->uploadfiles     = 1;
            $service->timecreated     = time();
            $service->id = $DB->insert_record('external_services', $service);
        }
        // Lista debe coincidir con db/services.php['ValidaNet API']['functions'].
        // Si añades funciones, hacerlo en AMBOS archivos: services.php (para
        // que el upgrade reconcilie) y aquí (para instalaciones existentes
        // que re-ejecutan el wizard).
        $functions = [
            'core_webservice_get_site_info',
            'core_course_get_courses',
            'core_course_get_courses_by_field',
            'core_course_get_contents',
            'core_course_search_courses',
            'core_course_get_categories',
            'core_user_get_users_by_field',
            'core_user_get_users',
            'core_user_create_users',
            'core_user_update_users',
            'core_user_delete_users',
            'core_enrol_get_enrolled_users',
            'core_enrol_get_users_courses',
            'enrol_manual_enrol_users',
            'enrol_manual_unenrol_users',
            // SSO autologin para alumnos CampusStore
            'tool_mobile_get_autologin_key',
            'tool_mobile_get_public_config',
            'auth_email_get_signup_settings',
            'core_group_get_course_groups',
            'core_group_get_group_members',
            'core_completion_get_course_completion_status',
            'core_completion_get_activities_completion_status',
            'core_completion_update_activity_completion_status_manually',
            'gradereport_user_get_grade_items',
            'gradereport_overview_get_course_grades',
            'core_grades_get_gradeitems',
            'mod_assign_get_assignments',
            'mod_assign_get_submission_status',
            'mod_assign_get_submissions',
            'mod_assign_save_grade',
            'mod_assign_save_grades',
            'mod_quiz_get_quizzes_by_courses',
            'mod_quiz_get_user_attempts',
            'mod_quiz_get_attempt_data',
            'mod_quiz_get_attempt_review',
            'mod_forum_get_forums_by_courses',
            'mod_forum_get_discussion_posts',
            'mod_resource_get_resources_by_courses',
            'mod_url_get_urls_by_courses',
            'mod_page_get_pages_by_courses',
            'core_message_send_messages',
            'core_message_get_messages',
            // — Courses AI Builder (1.6.1+) — funciones de escritura/creación
            'core_course_create_courses',
            'core_course_update_courses',
            'core_course_delete_courses',
            'core_course_delete_modules',
            'core_course_edit_section',
            'core_course_create_categories',
            'core_course_get_course_module',
            'core_files_upload',
            'core_files_get_files',
            'core_role_assign_roles',
            'core_role_unassign_roles',
            'mod_glossary_get_glossaries_by_courses',
            'mod_glossary_add_entry',
            'mod_quiz_save_questions',
            'mod_forum_add_discussion',
            'mod_feedback_get_feedback_access_information',
            'mod_feedback_get_feedbacks_by_courses',
            'mod_feedback_get_analysis',
            'mod_feedback_get_responses_analysis',
            'mod_feedback_get_finished_responses',
            'mod_feedback_get_non_respondents',
            'core_h5p_get_trusted_h5p_file',
            'mod_h5pactivity_get_h5pactivity_access_information',
            'mod_h5pactivity_get_h5pactivities_by_courses',
            'mod_h5pactivity_get_user_attempts',
            // — Custom WS del plugin (1.7.0+)
            'local_validanet_update_section',
            'local_validanet_create_page',
            // — Batch v1.8.0
            'local_validanet_create_module',
            'local_validanet_create_quiz',
            'local_validanet_add_quiz_questions_gift',
            'local_validanet_set_feedback_items',
            'local_validanet_update_page',
            'local_validanet_create_resource_with_file',
            'local_validanet_debug_read_quiz_questions',
            'local_validanet_debug_read_feedback_item',
            'local_validanet_add_quiz_questions_json',
            'local_validanet_delete_modules',
            'local_validanet_create_h5p_activity',
        ];
        foreach ($functions as $fname) {
            if (!$DB->record_exists('external_services_functions',
                ['externalserviceid' => $service->id, 'functionname' => $fname])) {
                $DB->insert_record('external_services_functions', [
                    'externalserviceid' => $service->id,
                    'functionname'      => $fname,
                ]);
            }
        }
        $existing = get_config('local_validanet', 'moodle_token');
        if (!$existing) {
            $token                          = md5(uniqid(rand(), true));
            $tokenrecord                    = new stdClass();
            $tokenrecord->token             = $token;
            $tokenrecord->tokentype         = EXTERNAL_TOKEN_PERMANENT;
            $tokenrecord->userid            = $admin->id;
            $tokenrecord->externalserviceid = $service->id;
            $tokenrecord->contextid         = context_system::instance()->id;
            $tokenrecord->creatorid         = $admin->id;
            $tokenrecord->timecreated       = time();
            $tokenrecord->validuntil        = 0;
            $tokenrecord->iprestriction     = null;
            $tokenrecord->name              = 'ValidaNet Token';
            $DB->insert_record('external_tokens', $tokenrecord);
            set_config('moodle_token', $token, 'local_validanet');
        } else {
            $token = $existing;
        }
        set_config('moodle_url', $CFG->wwwroot, 'local_validanet');
        echo json_encode([
            'ok'         => true,
            'token'      => $token,
            'moodle_url' => $CFG->wwwroot,
            'functions'  => count($functions),
        ]);
        break;

    case 'test_connection':
        $apikey = required_param('apikey', PARAM_TEXT);
        set_config('apikey', $apikey, 'local_validanet');
        $apiurl = get_config('local_validanet', 'apiurl') ?: 'https://app.validanet.cl';
        $moodle_token = get_config('local_validanet', 'moodle_token') ?: '';
        $moodle_url   = get_config('local_validanet', 'moodle_url') ?: $CFG->wwwroot;
        $ping_body    = json_encode([
            'moodle_token' => $moodle_token,
            'moodle_url'   => $moodle_url,
        ]);
        $ch     = curl_init("$apiurl/api/validanet/moodle/ping");
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $ping_body,
            CURLOPT_HTTPHEADER     => [
                "Authorization: Bearer $apikey",
                "Content-Type: application/json",
            ],
        ]);
        $resp = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $data = @json_decode($resp, true);
        if ($code === 200 && !empty($data['ok'])) {
            // Guardar gateway_key per-cliente devuelto por backend (reemplaza
            // el legacy default 'vn-gw-2026-norteduc-plugin-secret' hardcoded
            // que figura en el repo público).
            if (!empty($data['gateway_key'])) {
                set_config('gateway_key', $data['gateway_key'], 'local_validanet');
            }
            set_config('wizard_done', 1, 'local_validanet');
            echo json_encode([
                'ok'           => true,
                'client_id'    => $data['client_id'] ?? '',
                'gateway_key'  => !empty($data['gateway_key']) ? 'rotated' : 'kept',
            ]);
        } else {
            echo json_encode(['ok' => false, 'error' => "HTTP $code — Verifica tu API Key"]);
        }
        break;

    default:
        echo json_encode(['ok' => false, 'error' => 'Acción no válida']);
}
