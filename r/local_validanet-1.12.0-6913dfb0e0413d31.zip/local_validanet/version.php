<?php
defined('MOODLE_INTERNAL') || die();
$plugin->component = 'local_validanet';
$plugin->version   = 2026051902;
$plugin->requires  = 2023042400; // Moodle 4.2+ (\core_external\external_api)
$plugin->release   = '1.12.0';
$plugin->maturity  = MATURITY_STABLE;
// Servidor de actualizaciones ValidaNet — Moodle consulta diariamente
// (core\task\check_for_updates) y notifica al admin si hay versión nueva.
$plugin->updateurl = 'https://app.validanet.cl/api/moodle/plugin-updates';
