<?php
$string['pluginname']       = 'ValidaNet';
$string['privacy:metadata'] = 'ValidaNet no almacena datos personales.';
$string['apikey']           = 'API Key';
$string['apiurl']           = 'URL de la API';
$string['wizard_title']     = 'Asistente de configuración ValidaNet';

// Strings usados por loginas.php (modo soporte)
$string['expired']          = 'El enlace expiró. Vuelve al panel ValidaNet y genera uno nuevo.';
$string['nogwkey']          = 'Plugin sin gateway_key configurada — re-ejecuta el wizard de ValidaNet.';
$string['badsig']           = 'Firma inválida. La URL fue manipulada o el gateway_key no coincide entre Moodle y ValidaNet.';
$string['nologinasadmin']   = 'No se permite "Entrar como" a otro administrador del sitio.';
