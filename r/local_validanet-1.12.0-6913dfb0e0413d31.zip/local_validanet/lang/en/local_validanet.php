<?php
$string['pluginname']       = 'ValidaNet';
$string['privacy:metadata'] = 'ValidaNet does not store personal data.';
$string['apikey']           = 'API Key';
$string['apiurl']           = 'API URL';
$string['wizard_title']     = 'ValidaNet Setup Wizard';

// Strings used by loginas.php (support mode)
$string['expired']          = 'The link has expired. Go back to the ValidaNet panel and generate a new one.';
$string['nogwkey']          = 'Plugin without gateway_key configured — re-run the ValidaNet wizard.';
$string['badsig']           = 'Invalid signature. The URL was tampered with or the gateway_key does not match between Moodle and ValidaNet.';
$string['nologinasadmin']   = 'Login-as not allowed for another site administrator.';
