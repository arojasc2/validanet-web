<?php
// Función WS: local_validanet_create_module
// Genérica para crear actividades simples vía add_moduleinfo(). Soporta los
// modulenames que el Builder usa fuera de page/quiz/feedback (glossary,
// forum, url, label, resource). Para page/quiz/feedback existen funciones
// dedicadas porque su configuración es más compleja.

namespace local_validanet\external;

defined('MOODLE_INTERNAL') || die();

use core_external\external_api;
use core_external\external_function_parameters;
use core_external\external_value;
use core_external\external_single_structure;
use context_course;
use stdClass;
use invalid_parameter_exception;

class create_module extends external_api {

    /** Modulenames permitidos (allowlist). page/quiz tienen su WS dedicada. */
    private const ALLOWED_MODULES = [
        'glossary', 'forum', 'url', 'label', 'resource', 'book', 'lesson',
        'feedback', 'assign',
    ];

    /** Hardening v1.10: campos permitidos en props_json por modulename. Cualquier
     * campo fuera de esta allowlist es ignorado silenciosamente. Evita que un
     * cliente malicioso setee fields críticos via merge libre. */
    private const ALLOWED_PROPS_PER_MODULE = [
        'glossary' => ['globalglossary','mainglossary','defaultapproval',
                        'allowduplicatedentries','displayformat','showspecial',
                        'showalphabet','showall','allowcomments','usedynalink',
                        'allowprintview','rsstype','rssarticles','assessed',
                        'assesstimestart','assesstimefinish','scale','entbypage',
                        'editalways','approvaldisplayformat'],
        'forum' => ['type','maxbytes','maxattachments','forcesubscribe',
                     'trackingtype','rsstype','rssarticles','grade_forum',
                     'scale','assessed','displaywordcount','assesstimestart',
                     'assesstimefinish','cutoffdate','duedate'],
        'url' => ['externalurl','display','displayoptions','printintro','parameters'],
        'label' => [],
        'resource' => ['display','displayoptions','printintro','filterfiles',
                        'revision','files','mainfile','tobemigrated','legacyfiles',
                        'legacyfileslast'],
        'book' => ['numbering','navstyle','customtitles'],
        'lesson' => ['practice','modattempts','usepassword','password','dependency',
                      'conditions','grade','custom','ongoing','usemaxgrade',
                      'maxanswers','maxattempts','review','nextpagedefault',
                      'feedback','minquestions','maxpages','timelimit','retake',
                      'activitylink','mediafile','progressbar','displayleft',
                      'displayleftif','slideshow','available','deadline'],
        'feedback' => ['anonymous','email_notification','multiple_submit',
                        'autonumbering','site_after_submit','page_after_submit',
                        'page_after_submitformat','publish_stats',
                        'timeopen','timeclose','completionsubmit'],
        'assign' => [
            // Submission types nativos de Moodle
            'assignsubmission_onlinetext_enabled',
            'assignsubmission_onlinetext_wordlimit_enabled',
            'assignsubmission_onlinetext_wordlimit',
            'assignsubmission_file_enabled',
            'assignsubmission_file_maxfiles',
            'assignsubmission_file_maxsizebytes',
            'assignsubmission_file_filetypes',
            // Feedback plugins
            'assignfeedback_comments_enabled',
            'assignfeedback_file_enabled',
            // Fechas y nota
            'allowsubmissionsfromdate','duedate','cutoffdate','gradingduedate',
            'grade','grademethod','gradepass',
            // Comportamiento
            'submissiondrafts','requiresubmissionstatement',
            'sendnotifications','sendlatenotifications','sendstudentnotifications',
            'teamsubmission','requireallteammemberssubmit','blindmarking',
            'attemptreopenmethod','maxattempts','markingworkflow','markingallocation',
            'completionsubmit',
            // Visibilidad de la descripción en la página del curso (0 = solo
            // dentro de la actividad; 1 = se muestra en la sección del curso)
            'showdescription',
        ],
    ];

    public static function execute_parameters(): external_function_parameters {
        return new external_function_parameters([
            'courseid'   => new external_value(PARAM_INT, 'ID del curso'),
            'section'    => new external_value(PARAM_INT, 'Número de sección (0-based)'),
            'modulename' => new external_value(PARAM_ALPHA, 'Nombre del módulo Moodle (glossary, forum, url, label, resource, book, lesson)'),
            'name'       => new external_value(PARAM_TEXT, 'Nombre de la actividad'),
            'intro'      => new external_value(PARAM_RAW, 'Descripción/intro HTML', VALUE_DEFAULT, ''),
            'props_json' => new external_value(PARAM_RAW, 'JSON con campos específicos del módulo (e.g. {"externalurl":"..."} para url, {"assessed":0} para glossary)', VALUE_DEFAULT, '{}'),
            'visible'    => new external_value(PARAM_BOOL, 'Visible para alumnos', VALUE_DEFAULT, true),
            'completion' => new external_value(PARAM_INT, '0=ninguna 1=manual 2=automatic', VALUE_DEFAULT, 0),
            'completionview' => new external_value(PARAM_BOOL, 'Completar al ver', VALUE_DEFAULT, false),
            'availability_json' => new external_value(PARAM_RAW, 'JSON Moodle availability', VALUE_DEFAULT, ''),
        ]);
    }

    public static function execute(int $courseid, int $section, string $modulename,
                                    string $name, string $intro = '',
                                    string $props_json = '{}', bool $visible = true,
                                    int $completion = 0, bool $completionview = false,
                                    string $availability_json = ''): array {
        global $DB, $CFG;
        require_once($CFG->dirroot . '/course/lib.php');
        require_once($CFG->dirroot . '/course/modlib.php');
        require_once($CFG->libdir . '/resourcelib.php');

        $params = self::validate_parameters(self::execute_parameters(), [
            'courseid' => $courseid, 'section' => $section, 'modulename' => $modulename,
            'name' => $name, 'intro' => $intro, 'props_json' => $props_json,
            'visible' => $visible, 'completion' => $completion,
            'completionview' => $completionview, 'availability_json' => $availability_json,
        ]);
        if (!in_array($params['modulename'], self::ALLOWED_MODULES, true)) {
            throw new invalid_parameter_exception(
                'modulename no permitido: ' . $params['modulename']
                . '. Usar uno de: ' . implode(', ', self::ALLOWED_MODULES)
            );
        }

        $context = context_course::instance($params['courseid']);
        self::validate_context($context);
        require_capability('moodle/course:manageactivities', $context);

        $props = json_decode($params['props_json'], true);
        if (!is_array($props)) {
            $props = [];
        }
        // Hardening: filtrar props por allowlist específica del modulename.
        // Solo se aceptan campos conocidos del schema de ese mod.
        $allowed = self::ALLOWED_PROPS_PER_MODULE[$params['modulename']] ?? [];
        $props = array_intersect_key($props, array_flip($allowed));

        $course = get_course($params['courseid']);
        $module = $DB->get_record('modules', ['name' => $params['modulename']], '*', MUST_EXIST);
        course_create_sections_if_missing($course, [$params['section']]);

        $moduleinfo = new stdClass();
        $moduleinfo->course             = $course->id;
        $moduleinfo->module             = $module->id;
        $moduleinfo->modulename         = $params['modulename'];
        $moduleinfo->section            = $params['section'];
        $moduleinfo->name               = trim($params['name']);
        $moduleinfo->visible            = $params['visible'] ? 1 : 0;
        $moduleinfo->visibleoncoursepage = 1;
        $moduleinfo->intro              = $params['intro'];
        $moduleinfo->introformat        = FORMAT_HTML;
        $moduleinfo->cmidnumber         = '';
        $moduleinfo->groupmode          = 0;
        $moduleinfo->groupingid         = 0;
        $moduleinfo->completion         = (int) $params['completion'];
        if ($params['completionview']) {
            $moduleinfo->completionview = 1;
        }
        if (!empty($params['availability_json'])) {
            $moduleinfo->availability = $params['availability_json'];
        }
        $moduleinfo->showdescription    = empty($params['intro']) ? 0 : 1;

        // Aplicar defaults razonables por modulename + override desde props
        $defaults = self::defaults_for($params['modulename']);
        foreach ($defaults as $k => $v) {
            $moduleinfo->$k = $v;
        }
        foreach ($props as $k => $v) {
            // No permitir override de campos críticos
            if (in_array($k, ['course','module','modulename','section'])) continue;
            $moduleinfo->$k = $v;
        }

        $created = add_moduleinfo($moduleinfo, $course);

        global $USER;
        error_log(sprintf('[validanet_audit] user=%d action=create_module '
            . 'modulename=%s course=%d section=%d cmid=%d',
            $USER->id, $params['modulename'], $params['courseid'],
            $params['section'], (int) $created->coursemodule));

        return [
            'ok'         => true,
            'cmid'       => (int) $created->coursemodule,
            'instanceid' => (int) $created->instance,
            'modulename' => $params['modulename'],
            'section'    => (int) $params['section'],
        ];
    }

    /** Defaults por tipo de actividad — campos que el _add_instance del mod requiere. */
    private static function defaults_for(string $modulename): array {
        switch ($modulename) {
            case 'glossary':
                return [
                    'globalglossary'        => 0,
                    'mainglossary'          => 0,
                    'defaultapproval'       => 1,
                    'allowduplicatedentries' => 0,
                    'displayformat'         => 'dictionary',
                    'showspecial'           => 1,
                    'showalphabet'          => 1,
                    'showall'               => 1,
                    'allowcomments'         => 0,
                    'usedynalink'           => 0,
                    'allowprintview'        => 1,
                    'rsstype'               => 0,
                    'rssarticles'           => 0,
                    'assessed'              => 0,
                    'scale'                 => 0,
                    'entbypage'             => 10,
                    'editalways'            => 0,
                ];
            case 'forum':
                return [
                    'type'              => 'general',
                    'maxbytes'          => 0,
                    'maxattachments'    => 1,
                    'forcesubscribe'    => 0,
                    'trackingtype'      => 1,
                    'rsstype'           => 0,
                    'rssarticles'       => 0,
                    'grade_forum'       => 0,
                    'scale'             => 0,
                    'assessed'          => 0,
                    'displaywordcount'  => 0,
                ];
            case 'url':
                return [
                    'externalurl' => '',
                    'display'     => RESOURCELIB_DISPLAY_AUTO,
                    'printintro'  => 1,
                ];
            case 'label':
                return [];
            case 'resource':
                return ['display' => RESOURCELIB_DISPLAY_AUTO];
            case 'book':
                return [
                    'numbering'    => 1,
                    'navstyle'     => 1,
                    'customtitles' => 0,
                ];
            case 'feedback':
                return [
                    'anonymous'           => 1, // FEEDBACK_ANONYMOUS_YES
                    'email_notification'  => 0,
                    'multiple_submit'     => 0,
                    'autonumbering'       => 1,
                    'site_after_submit'   => '',
                    'page_after_submit'   => '',
                    'page_after_submitformat' => FORMAT_HTML,
                    'publish_stats'       => 0,
                    'timeopen'            => 0,
                    'timeclose'           => 0,
                    'completionsubmit'    => 1, // alumno debe enviar para completar
                ];
            case 'assign':
                // Defaults: archivo + texto online habilitados, hasta 5 archivos
                // de 20 MB cada uno, completar = entregar la tarea.
                return [
                    'assignsubmission_onlinetext_enabled'           => 1,
                    'assignsubmission_onlinetext_wordlimit_enabled' => 0,
                    'assignsubmission_onlinetext_wordlimit'         => 0,
                    'assignsubmission_file_enabled'                 => 1,
                    'assignsubmission_file_maxfiles'                => 5,
                    'assignsubmission_file_maxsizebytes'            => 20971520, // 20 MB
                    'assignsubmission_file_filetypes'               => '',
                    'assignfeedback_comments_enabled'               => 1,
                    'assignfeedback_file_enabled'                   => 0,
                    'allowsubmissionsfromdate'                      => 0,
                    'duedate'                                       => 0,
                    'cutoffdate'                                    => 0,
                    'gradingduedate'                                => 0,
                    'grade'                                         => 100,
                    'grademethod'                                   => 0,
                    'gradepass'                                     => 60,
                    'submissiondrafts'                              => 0,
                    'requiresubmissionstatement'                    => 0,
                    'sendnotifications'                             => 0,
                    'sendlatenotifications'                         => 1,
                    'sendstudentnotifications'                      => 1,
                    'teamsubmission'                                => 0,
                    'requireallteammemberssubmit'                   => 0,
                    'blindmarking'                                  => 0,
                    'attemptreopenmethod'                           => 'none',
                    'maxattempts'                                   => -1,
                    'markingworkflow'                               => 0,
                    'markingallocation'                             => 0,
                    'completionsubmit'                              => 1,
                ];
            case 'lesson':
                return [
                    'practice'       => 0,
                    'modattempts'    => 0,
                    'usepassword'    => 0,
                    'dependency'     => 0,
                    'conditions'     => '',
                    'grade'          => 100,
                    'custom'         => 0,
                    'ongoing'        => 0,
                    'usemaxgrade'    => 0,
                    'maxanswers'     => 4,
                    'maxattempts'    => 1,
                    'review'         => 0,
                    'nextpagedefault' => 0,
                    'feedback'       => 1,
                    'minquestions'   => 0,
                    'maxpages'       => 0,
                    'timelimit'      => 0,
                    'retake'         => 1,
                    'activitylink'   => 0,
                    'mediafile'      => 0,
                    'progressbar'    => 0,
                    'displayleft'    => 0,
                    'displayleftif'  => 0,
                    'slideshow'      => 0,
                    'available'      => 0,
                    'deadline'       => 0,
                ];
        }
        return [];
    }

    public static function execute_returns(): external_single_structure {
        return new external_single_structure([
            'ok'         => new external_value(PARAM_BOOL, 'Éxito'),
            'cmid'       => new external_value(PARAM_INT, 'course_modules.id'),
            'instanceid' => new external_value(PARAM_INT, 'ID en la tabla del módulo'),
            'modulename' => new external_value(PARAM_ALPHA, 'Tipo de módulo creado'),
            'section'    => new external_value(PARAM_INT, 'Número de sección'),
        ]);
    }
}
